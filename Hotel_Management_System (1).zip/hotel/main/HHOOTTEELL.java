package hotel.main;

    
import hotel.core.*;
import hotel.exceptions.NotAvailable;
import hotel.rooms.RoomHolder;
import java.util.Scanner;

public class HHOOTTEELL {

    public static void main(String[] args) {

        // Restore previously saved hotel data
        

        // Both extend abstract HotelService — polymorphism
        RoomService roomSvc = new RoomService();
        FoodService foodSvc = new FoodService();

        Scanner sc = new Scanner(System.in);
        int  ch, ch2;
        char wish;

        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║         HOTEL VIVANTA                ║");
        System.out.println("╚══════════════════════════════════════╝");

        outer:
        do {
            System.out.println("\n1.Room Details  \n2.Availability  \n3.Book  \n4.Order Food  \n5.Checkout  \n6.Exit");
            while (!sc.hasNextInt()) { System.out.println("Enter 1-6."); sc.next(); }
            ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.println("1.Luxury Double  \n2.Deluxe Double  \n3.Luxury Single  \n4.Deluxe Single");
                    while (!sc.hasNextInt()) sc.next();
                    ch2 = sc.nextInt();
                    roomSvc.features(ch2);
                    break;

                case 2:
                    System.out.println("1.Luxury Double  \n2.Deluxe Double  \n3.Luxury Single  \n4.Deluxe Single");
                    while (!sc.hasNextInt()) sc.next();
                    ch2 = sc.nextInt();
                    roomSvc.availability(ch2, true);   // overloaded version
                    break;

                case 3:
                    System.out.println("1.Luxury Double  \n2.Deluxe Double  \n3.Luxury Single  \n4.Deluxe Single");
                    while (!sc.hasNextInt()) sc.next();
                    ch2 = sc.nextInt();
                    try {
                        roomSvc.bookRoom(ch2);         // THROWS NotAvailable
                    } catch (NotAvailable e) {         // CATCH custom exception
                        System.out.println("Booking Failed: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.print("Room number (1-60): ");
                    while (!sc.hasNextInt()) sc.next();
                    ch2 = sc.nextInt();
                    if (ch2 < 1 || ch2 > 60) { System.out.println("Invalid room number!"); break; }
                    foodSvc.orderFood(ch2);
                    break;

                case 5:
                    System.out.print("Room number (1-60): ");
                    while (!sc.hasNextInt()) sc.next();
                    ch2 = sc.nextInt();
                    if (ch2 < 1 || ch2 > 60) { System.out.println("Invalid room number!"); break; }
                    roomSvc.checkout(ch2);
                    break;

                case 6:
                    roomSvc.takeReview();
                    break outer;

                default:
                    System.out.println("Enter 1-6.");
            }

            System.out.print("\nContinue? (y/n): ");
            wish = sc.next().charAt(0);
            while (!(wish=='y'||wish=='Y'||wish=='n'||wish=='N')) {
                System.out.println("y or n only.");
                wish = sc.next().charAt(0);
            }

        } while (wish == 'y' || wish == 'Y');

        
        System.out.println("\nThank you! Total transactions: " + HotelService.totalTransactions);
    }
}
