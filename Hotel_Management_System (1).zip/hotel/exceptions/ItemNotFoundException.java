package hotel.exceptions;

public class ItemNotFoundException extends Exception {

    private final String itemName;   

    public ItemNotFoundException(String itemName) {
        super("Food item '" + itemName + "' not found in menu!");
        this.itemName = itemName;
    }

    public String getItemName() { return itemName; }

    @Override
    public String toString() {   // Method Overriding
        return "ItemNotFoundException: " + getMessage();
    }
}
