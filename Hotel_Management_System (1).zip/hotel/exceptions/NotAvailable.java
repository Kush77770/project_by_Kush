package hotel.exceptions;


public class NotAvailable extends Exception {

    private final int roomNumber;   

    //  Constructor Overloading 
    public NotAvailable() {
        super("Room Not Available!");
        this.roomNumber = -1;
    }

    public NotAvailable(int roomNumber) {
        super("Room " + roomNumber + " is Not Available!");
        this.roomNumber = roomNumber;
    }

    public int getRoomNumber() { return roomNumber; }

    @Override
    public String toString() {   // Method Overriding
        return "NotAvailable: " + getMessage();
    }
}
