package hotel.core;

import hotel.exceptions.NotAvailable;
import hotel.rooms.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class RoomService extends HotelService implements Reviewable {

    private static final Scanner sc = new Scanner(System.in);

    @Override 
    public String getServiceName() { 
        return "Room Service"; 
    }

    @Override
    public void showMenu() {
        System.out.println("1.Features  2.Availability  3.Book  4.Checkout");
    }

    // Displays room details based on type selected by user
    public void features(int rtype) {
        printServiceBanner();
        switch (rtype) {
            case 1: System.out.println("Luxury Double | AC: Yes | Breakfast: Yes | Rs.4000/day"); break;
            case 2: System.out.println("Deluxe Double | AC: No  | Breakfast: Yes | Rs.3000/day"); break;
            case 3: System.out.println("Luxury Single | AC: Yes | Breakfast: Yes | Rs.2200/day"); break;
            case 4: System.out.println("Deluxe Single | AC: No  | Breakfast: Yes | Rs.1200/day"); break;
            default: System.out.println("Invalid room type.");
        }
    }

    // Counts how many rooms are currently free
    public void availability(int rtype) {
        int count = 0;
        switch (rtype) {
            case 1: for (Doubleroom r : holder.luxuryDouble) if (r == null) count++; break;
            case 2: for (Doubleroom r : holder.deluxeDouble) if (r == null) count++; break;
            case 3: for (Singleroom r : holder.luxurySingle) if (r == null) count++; break;
            case 4: for (Singleroom r : holder.deluxeSingle) if (r == null) count++; break;
            default: System.out.println("Invalid type."); return;
        }
        System.out.println("Available rooms: " + count);
    }

    // Overloaded method: also prints exact room numbers available
    public void availability(int rtype, boolean showNumbers) {
        availability(rtype);
        if (!showNumbers) return;

        System.out.print("Available room numbers: ");
        switch (rtype) {
            case 1: for (int i=0;i<holder.luxuryDouble.length;i++) if(holder.luxuryDouble[i]==null) System.out.print((i+1)+" ");  break;
            case 2: for (int i=0;i<holder.deluxeDouble.length;i++) if(holder.deluxeDouble[i]==null) System.out.print((i+11)+" "); break;
            case 3: for (int i=0;i<holder.luxurySingle.length;i++) if(holder.luxurySingle[i]==null) System.out.print((i+31)+" "); break;
            case 4: for (int i=0;i<holder.deluxeSingle.length;i++) if(holder.deluxeSingle[i]==null) System.out.print((i+41)+" "); break;
        }
        System.out.println();
    }

    // Attempts booking; throws exception if no room is available
    public void bookRoom(int rtype) throws NotAvailable {
        int rn = selectRoom(rtype);

        // If no valid room selected, booking cannot proceed
        if (rn == -1) throw new NotAvailable();

        collectAndBook(rtype, rn);
        System.out.println("Room Booked Successfully!");
        totalTransactions++;
    }

    // Handles room selection with validation (correct type + not already booked)
    private int selectRoom(int rtype) {
        System.out.println("\nAvailable rooms:");
        availability(rtype, true);

        while (true) {
            System.out.print("Enter room number: ");

            // Prevents crash if user enters non-integer
            if (!sc.hasNextInt()) { 
                sc.next(); 
                System.out.println("Integers only."); 
                continue; 
            }

            int rn  = sc.nextInt();
            int idx = holder.getIndexByRoomNo(rn);
            int rt  = holder.getRoomType(rn);

            if (rt != rtype || idx < 0) {
                System.out.println("Invalid room number.");
                continue;
            }

            // Ensures room is not already occupied
            if (holder.getRoomByNumber(rn) != null) {
                System.out.println("Already booked!");
                continue;
            }

            return rn;
        }
    }

    // Collects guest details and assigns room object accordingly
    private void collectAndBook(int rtype, int roomNo) {
        String name    = readName("Guest name: ");
        String contact = readContact("Contact number: ");
        String gender  = readGender("Gender (Male/Female/Other): ");

        LocalDate[] dates  = readDates();
        LocalDate checkIn  = dates[0], checkOut = dates[1];

        long days  = ChronoUnit.DAYS.between(checkIn, checkOut);
        System.out.println("Total Days: " + days);

        int price = holder.getPriceForType(rtype);
        int idx   = holder.getIndexByRoomNo(roomNo);

        // Double room requires second guest details
        if (rtype == 1 || rtype == 2) {
            String name2    = readName("Second guest name: ");
            String contact2 = readContact("Second guest contact: ");
            String gender2  = readGender("Second guest gender: ");

            Doubleroom dr = new Doubleroom(name, contact, gender,
                                           name2, contact2, gender2,
                                           checkIn, checkOut, days, price);

            if (rtype == 1) holder.luxuryDouble[idx] = dr;
            else            holder.deluxeDouble[idx] = dr;

        } else {
            // Single room booking
            Singleroom sr = new Singleroom(name, contact, gender,
                                           checkIn, checkOut, days, price);

            if (rtype == 3) holder.luxurySingle[idx] = sr;
            else            holder.deluxeSingle[idx] = sr;
        }
    }

    // Handles checkout with safe cleanup even if billing fails
    public void checkout(int roomNo) {
        AbstractRoom room  = holder.getRoomByNumber(roomNo);
        int idx   = holder.getIndexByRoomNo(roomNo);
        int rtype = holder.getRoomType(roomNo);

        if (room == null) { 
            System.out.println("Room is already empty."); 
            return; 
        }

        System.out.println("Room occupied by: " + room.getName());
        System.out.print("Confirm checkout? (y/n): ");
        char w = sc.next().charAt(0);

        if (w == 'y' || w == 'Y') {
            try {
                // Billing might fail, so it's wrapped safely
                room.displayBill();
                totalTransactions++;
            } catch (Exception e) {
                System.out.println("Error generating bill: " + e.getMessage());
            } finally {
                // Ensures room is freed no matter what happens above
                switch (rtype) {
                    case 1: holder.luxuryDouble[idx] = null; break;
                    case 2: holder.deluxeDouble[idx] = null; break;
                    case 3: holder.luxurySingle[idx] = null; break;
                    case 4: holder.deluxeSingle[idx] = null; break;
                }
                System.out.println("---- Checkout finalized ----");
            }

            System.out.println("Checked out successfully.");
        }
    }

    @Override
    public void takeReview() {
        int rating;

        printServiceBanner("Hotel Review");

        // Keeps asking until valid rating (1–5) is entered
        while (true) {
            System.out.print("Rate your experience (1-5): ");

            if (!sc.hasNextInt()) { 
                sc.next(); 
                System.out.println("Numbers only."); 
                continue; 
            }

            rating = sc.nextInt();

            if (rating < 1 || rating > 5) { 
                System.out.println("Enter 1-5."); 
                continue; 
            }

            break;
        }

        sc.nextLine();
        System.out.print("Write your review: ");
        String review = sc.nextLine();

        System.out.println("\nThank you for your feedback!");
        System.out.println("Rating : " + rating + "/5");
        System.out.println("Review : " + review);
        System.out.println(getReviewSummary(rating));
    }

    // Returns feedback message based on rating
    @Override
    public String getReviewSummary(int rating) {
        if (rating >= 4) return "We are glad you enjoyed your stay!";
        if (rating == 3) return "Thanks! We will strive to improve.";
        return "Sorry for the inconvenience. We'll work on our service.";
    }

    // Validates name: only alphabets and max length constraint
    private String readName(String prompt) {
        System.out.print(prompt);
        while (true) {
            String v = sc.nextLine().trim();

            if (v.matches("[a-zA-Z]+( [a-zA-Z]+)*") && v.length() <= 25) {
                return v;
            }

            System.out.print("Enter valid name (alphabets only, max 25 characters): ");
        }
    }

    // Ensures contact number is exactly 10 digits
    private String readContact(String prompt) {
        System.out.print(prompt);
        while (true) { 
            String v = sc.next(); 
            if (v.matches("\\d{10}")) return v; 
            System.out.print("10-digit only: "); 
        }
    }

    // Restricts gender input to predefined values
    private String readGender(String prompt) {
        System.out.print(prompt);
        while (true) {
            String v = sc.next();
            if (v.equalsIgnoreCase("male") || v.equalsIgnoreCase("female") || v.equalsIgnoreCase("other")) return v;
            System.out.print("Male/Female/Other: ");
        }
    }

    // Validates date format and logical correctness (no past check-in, valid checkout)
    private LocalDate[] readDates() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate checkIn, checkOut;

        while (true) {
            System.out.print("Check-in (dd-MM-yyyy): ");
            try {
                checkIn = LocalDate.parse(sc.next(), fmt);

                if (checkIn.isBefore(LocalDate.now())) { 
                    System.out.println("Cannot be in the past!"); 
                    continue; 
                }

                break;
            } catch (DateTimeParseException e) { 
                System.out.println("Invalid format."); 
            }
        }

        while (true) {
            System.out.print("Check-out (dd-MM-yyyy): ");
            try {
                checkOut = LocalDate.parse(sc.next(), fmt);

                if (!checkOut.isAfter(checkIn)) { 
                    System.out.println("Must be after check-in!"); 
                    continue; 
                }

                return new LocalDate[]{checkIn, checkOut};
            } catch (DateTimeParseException e) { 
                System.out.println("Invalid format."); 
            }
        }
    }
}