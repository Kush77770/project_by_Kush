package hotel.core;

// review-related methods
public interface Reviewable {

    // take user review
    void takeReview();

    // summary based on rating
    String getReviewSummary(int rating);
}