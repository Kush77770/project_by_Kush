package hotel.core;


public interface Billable {

    // implicitly public abstract
    double calculateBill();
    void   displayBill();

    // default method — provides bill header without forcing override
    default String getBillHeader() {
        return "\n**********************************************\n" +
               "              HOTEL BILL RECEIPT             \n" +
               "**********************************************";
    }
}
