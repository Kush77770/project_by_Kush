package hotel.core;


import hotel.rooms.RoomHolder;
import java.io.*;

public class FileService implements Runnable {

    // FINAL — backup filename, never changes
    private static final String BACKUP_FILE = "hotel_backup.dat";

    private final RoomHolder holderToSave;   // final — set once in constructor

    public FileService(RoomHolder holder) {
        this.holderToSave = holder;
    }

    // Runnable implementation — runs saveData in a background thread
    @Override
    public void run() {
        saveData(holderToSave);
    }

    // ── Save ──────────────────────────────────────
    public static void saveData(RoomHolder holder) {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(BACKUP_FILE));
            oos.writeObject(holder);
            System.out.println("");
        } catch (IOException e) {
            System.out.println("Save error: " + e.getMessage());
        } finally {
            // FINALLY — stream always closed to prevent file corruption
            if (oos != null) {
                try { oos.close(); } catch (IOException ignored) {}
            }
            System.out.println("");
        }
    }

    // ── Load ──────────────────────────────────────
    public static RoomHolder loadData() {
        File f = new File(BACKUP_FILE);
        if (!f.exists()) return new RoomHolder();

        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(f));
            RoomHolder loaded = (RoomHolder) ois.readObject();
            System.out.println("");
            return loaded;
        } catch (Exception e) {
            System.out.println("Load error: " + e.getMessage());
            return new RoomHolder();
        } finally {
            // FINALLY — stream always closed
            if (ois != null) {
                try { ois.close(); } catch (IOException ignored) {}
            }
        }
    }
}
