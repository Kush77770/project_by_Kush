package hotel.core;


import hotel.rooms.RoomHolder;

public abstract class HotelService {

    // protected — subclasses access directly (no getter needed)
    protected static RoomHolder holder = new RoomHolder();

    // FINAL — hotel name never changes
    protected static final String HOTEL_NAME = "Hotel Vivanta";

    // default (package-private) — shared across hotel.core package
    public static int totalTransactions = 0;

    // ── ABSTRACT METHODS — subclasses must implement ──
    public abstract void   showMenu();
    public abstract String getServiceName();

    // ── Concrete method ───────────────────────────
    public void printServiceBanner() {
        System.out.println("\n==============================================");
        System.out.println("  " + HOTEL_NAME + "" + getServiceName());
        System.out.println("==============================================");
    }

    // ── METHOD OVERLOADING — custom title ─────────
    public void printServiceBanner(String customTitle) {
        System.out.println("\n==============================================");
        System.out.println("  " + customTitle);
        System.out.println("==============================================");
    }

    public static void       setHolder(RoomHolder h) { holder = h; }
    public static RoomHolder getHolder()             { return holder; }
}
