package hotel.core;


import hotel.exceptions.ItemNotFoundException;
import hotel.food.Food;
import hotel.rooms.AbstractRoom;
import java.util.Scanner;

public class FoodService extends HotelService {

    private static final Scanner sc = new Scanner(System.in);

    // FINAL — menu text, never reassigned
    private static final String MENU = """
====================================================================================================
                              THE ULTIMATE PURE VEG GRAND MENU
====================================================================================================

[ REFRESHING BEVERAGES ]
1.Fresh Lime Soda .................... Rs.95      6.Masala Chaas .................... Rs.75
2.Mango Lassi ........................ Rs.130     7.Sweet Lassi ..................... Rs.110
3.Cold Coffee ........................ Rs.170     8.Filter Coffee ................... Rs.90
4.Virgin Mojito ...................... Rs.190     9.Jaljeera ........................ Rs.60
5.Badam Milk ......................... Rs.140     10.Rose Milk ....................... Rs.120

[ SOUPS & SHORBAS ]
11.Tomato Dhaniya Shorba .............. Rs.160     15.Veg Manchow Soup ............... Rs.180
12.Sweet Corn Soup .................... Rs.170     16.Lemon Coriander Soup ........... Rs.180
13.Hot & Sour Soup .................... Rs.175     17.Cream of Mushroom Soup ......... Rs.210
14.Palak Shorba ....................... Rs.165     18.Mixed Veg Clear Soup ........... Rs.150

[ STARTERS & TANDOORI ]
19.Paneer Tikka ....................... Rs.320     23.Hara Bhara Kabab ............... Rs.280
20.Mushroom Tikka ..................... Rs.340     24.Veg Seekh Kabab ................ Rs.290
21.Soya Chaap (Afgani) ................ Rs.310     25.Paneer 65 ...................... Rs.320
22.Dahi Ke Kabab ...................... Rs.300     26.Tandoori Broccoli .............. Rs.330

[ CHAAT & STREET SPECIALS ]
27.Pani Puri .......................... Rs.90      31.Sev Puri ........................ Rs.100
28.Dahi Puri .......................... Rs.110     32.Aloo Tikki Chaat ............... Rs.120
29.Papdi Chaat ........................ Rs.130     33.Raj Kachori ..................... Rs.150
30.Samosa (2pc) ....................... Rs.80      34.Kachori (2pc) ................... Rs.90

[ SOUTH INDIAN SPECIALS ]
35.Masala Dosa ........................ Rs.180     39.Paneer Dosa .................... Rs.220
36.Plain Dosa ......................... Rs.140     40.Rava Dosa ...................... Rs.170
37.Idli Sambhar (2pc) ................. Rs.120     41.Medu Vada (2pc) ................ Rs.140
38.Uttapam (Veg) ...................... Rs.160     42.Cheese Uttapam ................. Rs.190

[ MAIN COURSE PANEER SPECIALS ]
43.Paneer Butter Masala ............... Rs.350     47.Kadhai Paneer ................. Rs.340
44.Palak Paneer ....................... Rs.320     48.Paneer Lababdar ............... Rs.360
45.Shahi Paneer ....................... Rs.360     49.Paneer Pasanda ................ Rs.390
46.Matar Paneer ....................... Rs.310     50.Paneer Bhurji ................. Rs.380

[ MAIN COURSE VEG CURRIES ]
51.Mix Veg Curry ...................... Rs.290     56.Veg Jalfrezi .................. Rs.310
52.Malai Kofta ........................ Rs.370     57.Kaju Curry .................... Rs.420
53.Bhindi Do Pyaza .................... Rs.260     58.Aloo Gobhi .................... Rs.240
54.Baingan Bharta ..................... Rs.270     59.Methi Matar Malai ............. Rs.350
55.Dum Aloo Kashmiri .................. Rs.300     60.Chana Masala .................. Rs.260

[ DAL & LENTILS ]
61.Dal Makhani ........................ Rs.310     64.Dal Tadka ..................... Rs.240
62.Dal Fry (Lala Style) ............... Rs.220     65.Dal Palak ..................... Rs.260
63.Panchratna Dal ..................... Rs.280     66.Gujarati Dal .................. Rs.210

[ RICE & BIRYANI ]
67.Veg Dum Biryani .................... Rs.380     71.Hyderabadi Veg Biryani ........ Rs.395
68.Jeera Rice ......................... Rs.210     72.Steam Rice .................... Rs.160
69.Kashmiri Pulao ..................... Rs.360     73.Veg Pulao ..................... Rs.250
70.Curd Rice .......................... Rs.190     74.Lemon Rice .................... Rs.200

[ INDIAN BREADS ]
75.Tandoori Roti ...................... Rs.35      78.Butter Roti ................... Rs.45
76.Plain Naan ......................... Rs.55      79.Butter Naan ................... Rs.65
77.Garlic Naan ........................ Rs.90      80.Cheese Naan ................... Rs.120

[ DESSERTS ]
81.Gulab Jamun (2pc) ................. Rs.100     83.Rasmalai (2pc) ............... Rs.140
82.Jalebi (Hot) ....................... Rs.120     84.Rabri ........................ Rs.160

====================================================================================================
""";

    // ── Abstract method implementations 
    @Override public String getServiceName() { return "Food Service"; }
    @Override public void   showMenu()       { System.out.println(MENU); }

    // ── Order food by item number 
    public void orderFood(int roomNo) {
        AbstractRoom room = holder.getRoomByNumber(roomNo);
        if (room == null) { System.out.println("Room " + roomNo + " not booked."); return; }
        showMenu();
        char wish;
        do {
            try {
                int  itemNo = readItemNo();
                int  qty    = readQuantity();
                Food f      = new Food(itemNo, qty);
                room.getFood().add(f);
                System.out.println("Added: " + f);
            } catch (Exception e) {
                System.out.println("Order error: " + e.getMessage());
            } finally {
                // FINALLY — always executes after each order attempt
                System.out.println("(Order attempt processed)");
            }
            while (true) {
                System.out.print("Order more? (y/n): ");
                wish = sc.next().charAt(0);
                if (wish=='y'||wish=='Y'||wish=='n'||wish=='N') break;
                System.out.println("Invalid!");
            }
        } while (wish == 'y' || wish == 'Y');
    }

    // ── METHOD OVERLOADING — order by name, THROWS ─
    public void orderFood(int roomNo, String itemName, int qty) throws ItemNotFoundException {
        AbstractRoom room = holder.getRoomByNumber(roomNo);
        if (room == null) { System.out.println("Room not booked."); return; }
        Food f = new Food(itemName, qty);   // Food ctor 3 — may THROW
        room.getFood().add(f);
        System.out.println("Added by name: " + f);
    }

    // ── private helpers ───────────────────────────
    private int readItemNo() {
        while (true) {
            System.out.print("Item number (1-84): ");
            if (!sc.hasNextInt()) { sc.next(); System.out.println("Integer only."); continue; }
            int n = sc.nextInt();
            if (n < 1 || n > 84) { System.out.println("Choose 1-84."); continue; }
            return n;
        }
    }

    private int readQuantity() {
        while (true) {
            System.out.print("Quantity: ");
            if (!sc.hasNextInt()) { sc.next(); System.out.println("Integer only."); continue; }
            int q = sc.nextInt();
            if (q <= 0) { System.out.println("Must be > 0."); continue; }
            return q;
        }
    }
}
