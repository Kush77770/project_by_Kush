package hotel.food;


import hotel.exceptions.ItemNotFoundException;
import java.io.Serializable;

public class Food implements Serializable {

    private static final long serialVersionUID = 4L;

    // ── ACCESS MODIFIERS on fields ────────────────
    private int    itemNo;    // private — via getItemNo()
    private int    quantity;  // private — via getQuantity()
    private double price;     // private — via getPrice()
    private String itemName;  // private — via getItemName()

    // FINAL constant — tax rate never changes
    private static final double TAX_RATE = 0.05;

    // default (package-private) — accessible within hotel.food
    static final String[] ITEM_NAMES = {
        "Fresh Lime Soda","Mango Lassi","Cold Coffee","Virgin Mojito","Badam Milk",
        "Masala Chaas","Sweet Lassi","Filter Coffee","Jaljeera","Rose Milk",
        "Tomato Dhaniya Shorba","Sweet Corn Soup","Hot & Sour Soup","Palak Shorba","Veg Manchow Soup",
        "Lemon Coriander Soup","Cream of Mushroom Soup","Mixed Veg Clear Soup",
        "Paneer Tikka","Mushroom Tikka","Soya Chaap","Dahi Ke Kabab","Hara Bhara Kabab",
        "Veg Seekh Kabab","Paneer 65","Tandoori Broccoli",
        "Pani Puri","Dahi Puri","Papdi Chaat","Samosa","Sev Puri","Aloo Tikki","Raj Kachori","Kachori",
        "Masala Dosa","Plain Dosa","Idli Sambhar","Uttapam","Paneer Dosa","Rava Dosa","Medu Vada","Cheese Uttapam",
        "Paneer Butter Masala","Palak Paneer","Shahi Paneer","Matar Paneer","Kadhai Paneer",
        "Paneer Lababdar","Paneer Pasanda","Paneer Bhurji",
        "Mix Veg","Malai Kofta","Bhindi Do Pyaza","Baingan Bharta","Dum Aloo","Veg Jalfrezi","Kaju Curry",
        "Aloo Gobhi","Methi Matar Malai","Chana Masala",
        "Dal Makhani","Dal Fry","Panchratna Dal","Dal Tadka","Dal Palak","Gujarati Dal",
        "Veg Biryani","Jeera Rice","Kashmiri Pulao","Curd Rice","Hyderabadi Biryani",
        "Steam Rice","Veg Pulao","Lemon Rice",
        "Tandoori Roti","Plain Naan","Garlic Naan","Butter Roti","Butter Naan","Cheese Naan",
        "Gulab Jamun","Jalebi","Rasmalai","Rabri"
    };

    static final int[] ITEM_PRICES = {
        95,130,170,190,140,75,110,90,60,120,
        160,170,175,165,180,180,210,150,
        320,340,310,300,280,290,320,330,
        90,110,130,80,100,120,150,90,
        180,140,120,160,220,170,140,190,
        350,320,360,310,340,360,390,380,
        290,370,260,270,300,310,420,240,350,260,
        310,220,280,240,260,210,
        380,210,360,190,395,160,250,200,
        35,55,90,45,65,120,
        100,120,140,160
    };

    // ── CONSTRUCTOR OVERLOADING ───────────────────

    // Constructor 1: by item number + quantity
    public Food(int itemNo, int quantity) {
        this.itemNo   = itemNo;
        this.quantity = quantity;
        this.itemName = ITEM_NAMES[itemNo - 1];
        this.price    = ITEM_PRICES[itemNo - 1] * quantity;
    }

    // Constructor 2: with custom price override (OVERLOADED)
    public Food(int itemNo, int quantity, double customPrice) {
        this(itemNo, quantity);             // delegate to Constructor 1
        this.price = customPrice * quantity;
    }

    // Constructor 3: by item name string (OVERLOADED) — uses throw
    public Food(String itemName, int quantity) throws ItemNotFoundException {
        this.quantity = quantity;
        this.itemName = itemName;
        boolean found = false;
        for (int i = 0; i < ITEM_NAMES.length; i++) {
            if (ITEM_NAMES[i].equalsIgnoreCase(itemName)) {
                this.itemNo = i + 1;
                this.price  = ITEM_PRICES[i] * quantity;
                found = true;
                break;
            }
        }
        if (!found) throw new ItemNotFoundException(itemName); // THROW keyword
    }

    // ── Getters (encapsulation) ───────────────────
    public int    getItemNo()   { return itemNo;   }
    public int    getQuantity() { return quantity;  }
    public double getPrice()    { return price;     }
    public String getItemName() { return itemName;  }

    // ── METHOD OVERLOADING — getPriceWithTax ──────
    public double getPriceWithTax() {                       // uses default TAX_RATE
        return price + (price * TAX_RATE);
    }

    public double getPriceWithTax(double customRate) {      // OVERLOADED — custom rate
        return price + (price * customRate);
    }

    @Override
    public String toString() {  // Method Overriding
        return String.format("%-30s x%-4d Rs.%.2f", itemName, quantity, price);
    }
}
