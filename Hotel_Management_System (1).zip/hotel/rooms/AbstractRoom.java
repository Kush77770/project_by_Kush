package hotel.rooms;

import hotel.core.Billable;
import hotel.food.Food;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class AbstractRoom implements Serializable, Billable {

    private static final long serialVersionUID = 1L;

    // ── ALL FOUR ACCESS MODIFIERS on fields ───────
    public    String    name;        // public  — accessible everywhere
    protected String    contact;     // protected — subclasses + same package
    protected String    gender;      // protected
    protected LocalDate checkIn;     // protected
    protected LocalDate checkOut;    // protected
    protected long      days;        // protected
    private   boolean   checkedOut;  // private — only AbstractRoom

    // default (package-private) — accessible within hotel.rooms package
    ArrayList<Food> food = new ArrayList<>();

    // FINAL field — set once, never changed
    protected final int pricePerDay;

    // ── ABSTRACT METHODS — subclasses MUST override ──
    public abstract String getRoomType();
    public abstract void   displayDetails();

    // ── CONSTRUCTOR OVERLOADING ───────────────────

    // Constructor 1: minimal / default state
    protected AbstractRoom(int pricePerDay) {
        this.pricePerDay = pricePerDay;
        this.checkedOut  = false;
        this.name        = "";
    }

    // Constructor 2: full guest details
    protected AbstractRoom(String name, String contact, String gender,
                           LocalDate checkIn, LocalDate checkOut, long days,
                           int pricePerDay) {
        this.name        = name;
        this.contact     = contact;
        this.gender      = gender;
        this.checkIn     = checkIn;
        this.checkOut    = checkOut;
        this.days        = days;
        this.pricePerDay = pricePerDay;
        this.checkedOut  = false;
    }

    // ── Getters/Setters for private field ─────────
    public boolean         isCheckedOut()          { return checkedOut; }
    public void            setCheckedOut(boolean v) { this.checkedOut = v; }
    public long            getDays()               { return days; }
    public String          getName()               { return name; }
    public String          getContact()            { return contact; }
    public ArrayList<Food> getFood()               { return food; }

    // ── Billable interface implementation ─────────

    @Override
    public double calculateBill() {
        double total = pricePerDay * days;
        for (Food f : food) total += f.getPrice();
        return total;
    }

    @Override
    public void displayBill() {
        System.out.println(getBillHeader());   // interface default method
        System.out.printf("Room Type    : %s%n",  getRoomType());
        System.out.printf("Guest Name   : %s%n",  name);
        System.out.printf("Check-In     : %s%n",  checkIn);
        System.out.printf("Check-Out    : %s%n",  checkOut);
        System.out.printf("Days Stayed  : %d%n",  days);
        System.out.printf("Room Charges : Rs.%d x %d = Rs.%.2f%n",
                pricePerDay, days, (double) pricePerDay * days);
        System.out.println("\n===============");
        System.out.println("Food Charges:");
        System.out.println("===============");
        System.out.printf("%-30s %-8s %-10s%n", "Item", "Qty", "Price");
        System.out.println("-----------------------------------------------");
        for (Food f : food)
            System.out.printf("%-30s %-8d Rs.%-10.2f%n",
                    f.getItemName(), f.getQuantity(), f.getPrice());
        System.out.println("-----------------------------------------------");
        System.out.printf("TOTAL AMOUNT : Rs.%.2f%n", calculateBill());
        System.out.println("**********************************************\n");
    }

    // ── METHOD OVERLOADING — displayBill ──────────
    public void displayBill(boolean showHeader) {
        if (showHeader) displayBill();
        else System.out.printf("Total for %s: Rs.%.2f%n", name, calculateBill());
    }

    @Override
    public String toString() {   // Method Overriding
        return String.format("[%s] Guest: %s | Contact: %s | Days: %d",
                getRoomType(), name, contact, days);
    }
}
