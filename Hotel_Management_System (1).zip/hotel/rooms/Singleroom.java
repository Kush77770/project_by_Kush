package hotel.rooms;

import java.io.Serializable;
import java.time.LocalDate;

public class Singleroom extends AbstractRoom implements Serializable {

    private static final long serialVersionUID = 2L;

    // FINAL — instance label, cannot be reassigned after constructor
    private final String CATEGORY = "SINGLE";

    // ── CONSTRUCTOR OVERLOADING ───────────────────

    // Constructor 1: default / empty slot
    public Singleroom(int pricePerDay) {
        super(pricePerDay);   // SUPER → AbstractRoom(int)
    }

    // Constructor 2: full guest info
    public Singleroom(String name, String contact, String gender,
                      LocalDate checkIn, LocalDate checkOut, long days,
                      int pricePerDay) {
        super(name, contact, gender, checkIn, checkOut, days, pricePerDay); // SUPER
    }

    // ── METHOD OVERRIDING — abstract methods ──────

    @Override
    public String getRoomType() {
        return CATEGORY + " (Rs." + pricePerDay + "/day)";
    }

    @Override
    public void displayDetails() {
        System.out.println("---- Singleroom Details ----");
        System.out.println("Guest  : " + name);
        System.out.println("Gender : " + gender);
        System.out.println("Days   : " + days);
        System.out.printf("Bill   : Rs.%.2f%n", calculateBill());
    }

    // ── METHOD OVERLOADING — displayDetails ───────
    public void displayDetails(boolean showContact) {
        displayDetails();
        if (showContact) System.out.println("Contact: " + contact);
    }
}
