package hotel.rooms;


import java.io.Serializable;

public class RoomHolder implements Serializable {

    private static final long serialVersionUID = 5L;

    // FINAL capacity constants — never change
    public static final int LUXURY_DOUBLE_COUNT = 10;
    public static final int DELUXE_DOUBLE_COUNT = 20;
    public static final int LUXURY_SINGLE_COUNT = 10;
    public static final int DELUXE_SINGLE_COUNT = 20;

    // default (package-private) — accessible within hotel.rooms only
    public Doubleroom[] luxuryDouble = new Doubleroom[LUXURY_DOUBLE_COUNT];
    public Doubleroom[] deluxeDouble = new Doubleroom[DELUXE_DOUBLE_COUNT];
    public Singleroom[] luxurySingle = new Singleroom[LUXURY_SINGLE_COUNT];
    public Singleroom[] deluxeSingle = new Singleroom[DELUXE_SINGLE_COUNT];

    // FINAL price constants per room type
    public static final int LUXURY_DOUBLE_PRICE = 4000;  // rooms  1-10
    public static final int DELUXE_DOUBLE_PRICE = 3000;  // rooms 11-30
    public static final int LUXURY_SINGLE_PRICE = 2200;  // rooms 31-40
    public static final int DELUXE_SINGLE_PRICE = 1200;  // rooms 41-60

    // ── Helper Methods ────────────────────────────

    public AbstractRoom getRoomByNumber(int roomNo) {
        if (roomNo >= 1  && roomNo <= 10) return luxuryDouble[roomNo - 1];
        if (roomNo >= 11 && roomNo <= 30) return deluxeDouble[roomNo - 11];
        if (roomNo >= 31 && roomNo <= 40) return luxurySingle[roomNo - 31];
        if (roomNo >= 41 && roomNo <= 60) return deluxeSingle[roomNo - 41];
        return null;
    }

    public int getRoomType(int roomNo) {
        if (roomNo >= 1  && roomNo <= 10) return 1;
        if (roomNo >= 11 && roomNo <= 30) return 2;
        if (roomNo >= 31 && roomNo <= 40) return 3;
        if (roomNo >= 41 && roomNo <= 60) return 4;
        return -1;
    }

    public int getIndexByRoomNo(int roomNo) {
        if (roomNo >= 1  && roomNo <= 10) return roomNo - 1;
        if (roomNo >= 11 && roomNo <= 30) return roomNo - 11;
        if (roomNo >= 31 && roomNo <= 40) return roomNo - 31;
        if (roomNo >= 41 && roomNo <= 60) return roomNo - 41;
        return -1;
    }

    public int getPriceForType(int rtype) {
        switch (rtype) {
            case 1: return LUXURY_DOUBLE_PRICE;
            case 2: return DELUXE_DOUBLE_PRICE;
            case 3: return LUXURY_SINGLE_PRICE;
            case 4: return DELUXE_SINGLE_PRICE;
            default: return 0;
        }
    }
}
