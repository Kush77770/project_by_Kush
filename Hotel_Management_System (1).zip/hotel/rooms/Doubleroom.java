package hotel.rooms;

import java.io.Serializable;
import java.time.LocalDate;

public class Doubleroom extends Singleroom implements Serializable {

    private static final long serialVersionUID = 3L;

    // private — second guest data, accessed only via getters
    private String name2;
    private String contact2;
    private String gender2;

    // FINAL — label string, set once
    private final String GUEST2_LABEL = "Second Guest";

    // ── CONSTRUCTOR OVERLOADING ───────────────────

    // Constructor 1: default / empty slot
    public Doubleroom(int pricePerDay) {
        super(pricePerDay);   // SUPER → Singleroom → AbstractRoom
        this.name2    = "";
        this.contact2 = "";
        this.gender2  = "";
    }

    // Constructor 2: both guests, full info
    public Doubleroom(String name, String contact, String gender,
                      String name2, String contact2, String gender2,
                      LocalDate checkIn, LocalDate checkOut, long days,
                      int pricePerDay) {
        // SUPER — passes guest1 data up the inheritance chain
        super(name, contact, gender, checkIn, checkOut, days, pricePerDay);
        this.name2    = name2;
        this.contact2 = contact2;
        this.gender2  = gender2;
    }

    // ── Getters for second guest ──────────────────
    public String getName2()    { return name2;    }
    public String getContact2() { return contact2; }
    public String getGender2()  { return gender2;  }

    // ── METHOD OVERRIDING ─────────────────────────

    @Override
    public String getRoomType() {
        return "DOUBLE (Rs." + pricePerDay + "/day)";
    }

    @Override
    public void displayDetails() {
        super.displayDetails();   // SUPER — reuse Singleroom's output
        System.out.println(GUEST2_LABEL + ": " + name2 + " | " + gender2);
    }

    // ── METHOD OVERLOADING + OVERRIDING ───────────
    @Override
    public void displayDetails(boolean showContact) {
        displayDetails();
        if (showContact) {
            System.out.println("Contact1: " + contact);
            System.out.println("Contact2: " + contact2);
        }
    }

    @Override
    public String toString() {
        return super.toString() +   // SUPER — reuse AbstractRoom's string
               String.format(" | Guest2: %s", name2);
    }
}
