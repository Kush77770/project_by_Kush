/* ============================================================
   InvenPro IMS — app.js  (Enhanced Edition)
   30 Suppliers · 400 Products · 5 Warehouses
   Auto-price on PO/SO · Qty logic on Completed status only
   ============================================================ */

/* ── SEED DATA ───────────────────────────────────────────── */
var SEED = (function(){

  var warehouses = [
    { warehouse_id:"WH-001", name:"Alpha Hub - Pune",       location:"Plot 21, Bhosari MIDC, Pune",              manager:"Deepak Joshi",    capacity:6000, used:3800, phone:"020-27120001", created:"2023-01-10" },
    { warehouse_id:"WH-002", name:"Beta Store - Chennai",   location:"Manali Industrial Estate, Chennai",         manager:"Kavitha Rajan",   capacity:4000, used:2100, phone:"044-25941234", created:"2023-03-05" },
    { warehouse_id:"WH-003", name:"Gamma Depot - Surat",    location:"Sachin GIDC, Surat",                        manager:"Himesh Trivedi",  capacity:5000, used:3200, phone:"0261-2397001", created:"2023-04-20" },
    { warehouse_id:"WH-004", name:"Delta Center - Mumbai",  location:"Bhiwandi Logistics Park, Mumbai",           manager:"Neha Kulkarni",   capacity:7000, used:4500, phone:"022-25001234", created:"2023-06-15" },
    { warehouse_id:"WH-005", name:"Epsilon Store - Delhi",  location:"Sector 63, Noida Industrial Area, Delhi",   manager:"Arvind Chauhan",  capacity:5500, used:2900, phone:"011-45001234", created:"2023-08-01" }
  ];

  var suppliers = [
    { supplier_id:"SUP-001", name:"MechPro Industries",        contact:"Rajesh Sharma",    phone:"+91-9876543210", email:"rajesh@mechpro.in",      address:"Plot 14, MIDC, Pune",              rating:4.8, created:"2023-06-01" },
    { supplier_id:"SUP-002", name:"FluidTech Solutions",       contact:"Priya Menon",      phone:"+91-9123456789", email:"priya@fluidtech.in",      address:"52 Industrial Area, Chennai",      rating:4.2, created:"2023-07-15" },
    { supplier_id:"SUP-003", name:"AutoElec Systems",          contact:"Vikram Nair",      phone:"+91-9988776655", email:"vikram@autoelec.in",      address:"Electronics City, Bangalore",      rating:4.9, created:"2023-05-20" },
    { supplier_id:"SUP-004", name:"SafeGuard Supplies",        contact:"Anita Patel",      phone:"+91-9345678901", email:"anita@safeguard.in",      address:"Ring Road, Surat",                 rating:4.5, created:"2023-08-10" },
    { supplier_id:"SUP-005", name:"PrecisionTools Co.",        contact:"Suresh Kumar",     phone:"+91-9654321098", email:"suresh@prectools.in",     address:"Sector 44, Faridabad",             rating:4.6, created:"2023-09-01" },
    { supplier_id:"SUP-006", name:"IndoSteel Corp",            contact:"Manish Agarwal",   phone:"+91-9871234560", email:"manish@indosteel.in",     address:"Steel Complex, Bhilai",            rating:4.3, created:"2023-09-15" },
    { supplier_id:"SUP-007", name:"PowerDrive Electricals",    contact:"Sunita Reddy",     phone:"+91-9765432109", email:"sunita@powerdrive.in",    address:"Jeedimetla IE, Hyderabad",         rating:4.7, created:"2023-10-01" },
    { supplier_id:"SUP-008", name:"ChemSafe India",            contact:"Harish Iyer",      phone:"+91-9654123780", email:"harish@chemsafe.in",      address:"Vapi GIDC, Gujarat",               rating:4.1, created:"2023-10-20" },
    { supplier_id:"SUP-009", name:"HydroSeal Systems",         contact:"Meena Krishnan",   phone:"+91-9543210987", email:"meena@hydroseal.in",      address:"Coimbatore Industrial Est.",       rating:4.4, created:"2023-11-05" },
    { supplier_id:"SUP-010", name:"AirPower Components",       contact:"Sanjay Tiwari",    phone:"+91-9432109876", email:"sanjay@airpower.in",      address:"Dewas IE, Madhya Pradesh",         rating:4.6, created:"2023-11-20" },
    { supplier_id:"SUP-011", name:"ThermoTech Sensors",        contact:"Kavya Pillai",     phone:"+91-9321098765", email:"kavya@thermotech.in",     address:"Technopark, Trivandrum",           rating:4.8, created:"2023-12-01" },
    { supplier_id:"SUP-012", name:"ProPaint Industries",       contact:"Dinesh Gupta",     phone:"+91-9210987654", email:"dinesh@propaint.in",      address:"Patancheru IE, Hyderabad",         rating:3.9, created:"2023-12-15" },
    { supplier_id:"SUP-013", name:"GreenGrip Polymers",        contact:"Rekha Bose",       phone:"+91-9109876543", email:"rekha@greengrip.in",      address:"Haldia Petrochemical Comp.",       rating:4.2, created:"2024-01-05" },
    { supplier_id:"SUP-014", name:"MetalCraft Forgings",       contact:"Arun Joshi",       phone:"+91-8998765432", email:"arun@metalcraft.in",      address:"Rajkot Auto Cluster, Gujarat",     rating:4.5, created:"2024-01-20" },
    { supplier_id:"SUP-015", name:"EnergyTech Batteries",      contact:"Pooja Sharma",     phone:"+91-8887654321", email:"pooja@energytech.in",     address:"IMT Manesar, Haryana",             rating:4.7, created:"2024-02-01" },
    { supplier_id:"SUP-016", name:"UltraFilter Systems",       contact:"Ravi Nambiar",     phone:"+91-8776543210", email:"ravi@ultrafilter.in",     address:"Peenyam IE, Bangalore",            rating:4.3, created:"2024-02-15" },
    { supplier_id:"SUP-017", name:"VibeSeal Gaskets",          contact:"Amita Kulkarni",   phone:"+91-8665432109", email:"amita@vibeseal.in",       address:"Chakan MIDC, Pune",                rating:4.1, created:"2024-03-01" },
    { supplier_id:"SUP-018", name:"RoboArm Automation",        contact:"Tushar Patil",     phone:"+91-8554321098", email:"tushar@roboarm.in",       address:"Taloja MIDC, Navi Mumbai",         rating:4.9, created:"2024-03-10" },
    { supplier_id:"SUP-019", name:"GearMaster India",          contact:"Shweta Singh",     phone:"+91-8443210987", email:"shweta@gearmaster.in",    address:"Ludhiana Industrial Focal Pt.",    rating:4.4, created:"2024-03-15" },
    { supplier_id:"SUP-020", name:"SilentBear Lubricants",     contact:"Nikhil Verma",     phone:"+91-8332109876", email:"nikhil@silentbear.in",    address:"Silvassa IE, DNH",                 rating:4.0, created:"2024-03-20" },
    { supplier_id:"SUP-021", name:"ProTex Safety Wear",        contact:"Latha Naidu",      phone:"+91-8221098765", email:"latha@protex.in",         address:"Tirupur Textile City, TN",         rating:4.6, created:"2024-04-01" },
    { supplier_id:"SUP-022", name:"SteelBox Enclosures",       contact:"Mohit Jain",       phone:"+91-8110987654", email:"mohit@steelbox.in",       address:"Bhosari MIDC, Pune",               rating:4.3, created:"2024-04-05" },
    { supplier_id:"SUP-023", name:"AcuSense Instruments",      contact:"Preethi Rao",      phone:"+91-8009876543", email:"preethi@acusense.in",     address:"Peenya IE, Bangalore",             rating:4.8, created:"2024-04-10" },
    { supplier_id:"SUP-024", name:"HeatShield Materials",      contact:"Kiran Mehta",      phone:"+91-7998765432", email:"kiran@heatshield.in",     address:"Naroda GIDC, Ahmedabad",           rating:4.2, created:"2024-04-12" },
    { supplier_id:"SUP-025", name:"UniPipe Fittings",          contact:"Deepa Thomas",     phone:"+91-7887654321", email:"deepa@unipipe.in",        address:"Edayar IE, Kochi",                 rating:4.0, created:"2024-04-14" },
    { supplier_id:"SUP-026", name:"MagDrive Motors",           contact:"Abhijit Ghosh",    phone:"+91-7776543210", email:"abhijit@magdrive.in",     address:"Durgapur Steel City, WB",          rating:4.7, created:"2024-04-15" },
    { supplier_id:"SUP-027", name:"ClearVision Optics",        contact:"Nandini Iyer",     phone:"+91-7665432109", email:"nandini@clearvision.in",  address:"Oragadam IE, Chennai",             rating:4.5, created:"2024-04-16" },
    { supplier_id:"SUP-028", name:"ForceFit Fasteners",        contact:"Rajiv Kapoor",     phone:"+91-7554321098", email:"rajiv@forcefit.in",       address:"IMT Bawal, Rewari, Haryana",       rating:4.3, created:"2024-04-17" },
    { supplier_id:"SUP-029", name:"NanoCoat Technologies",     contact:"Swati Deshpande",  phone:"+91-7443210987", email:"swati@nanocoat.in",       address:"Taloja MIDC, Navi Mumbai",         rating:4.6, created:"2024-04-18" },
    { supplier_id:"SUP-030", name:"TurboVent Fans",            contact:"Ganesh Murti",     phone:"+91-7332109876", email:"ganesh@turbovent.in",     address:"Ambattur IE, Chennai",             rating:4.4, created:"2024-04-19" }
  ];

  /* 400 products across 5 warehouses and 30 suppliers */
  var products = [];
  var prodData = [
    // Mechanical
    ["Industrial Steel Bearings","ISB-6205","Mechanical",1240,45.99,200],
    ["Conveyor Belt 3M","CB-3M-B2","Mechanical",18,1250.00,10],
    ["Pneumatic Cylinder 50mm","PC-50MM","Mechanical",145,320.00,30],
    ["Chain Drive Assembly","CDA-40B","Mechanical",62,875.00,15],
    ["Roller Bearing 6308","RB-6308","Mechanical",890,55.50,150],
    ["Thrust Bearing 51210","TB-51210","Mechanical",340,88.00,75],
    ["Linear Guide Rail 1M","LGR-1000","Mechanical",75,420.00,20],
    ["Helical Gear Set","HGS-M2","Mechanical",130,560.00,25],
    ["Bevel Gear Pair 45°","BGP-45","Mechanical",88,690.00,20],
    ["Worm Gear Reducer","WGR-1:20","Mechanical",42,1450.00,10],
    ["Coupling Jaw Flexible","CJF-28","Mechanical",220,125.00,50],
    ["Spring Compression 50mm","SC-50S","Mechanical",500,18.50,100],
    ["Shock Absorber DA45","SAD-45","Mechanical",95,780.00,20],
    ["Rack and Pinion M2","RAP-M2","Mechanical",60,340.00,15],
    ["Timing Belt HTD5M","TBH-5M","Mechanical",180,95.00,40],
    ["Idler Pulley 80mm","IP-80MM","Mechanical",250,55.00,60],
    ["Shaft Coupling Rigid","SCR-25","Mechanical",170,148.00,40],
    ["Ball Screw 1605","BS-1605","Mechanical",55,1200.00,10],
    ["Linear Shaft 12mm","LS-12X500","Mechanical",200,85.00,50],
    ["Oil Seal 40×60","OS-4060","Mechanical",600,12.50,150],
    // Electronics
    ["PLC Control Module","PLC-S7-300","Electronics",34,879.00,20],
    ["Servo Motor 750W","SM-750W-AC","Electronics",9,1450.00,10],
    ["Variable Frequency Drive 5HP","VFD-5HP","Electronics",28,3200.00,5],
    ["Touch Screen HMI 7\"","HMI-7T","Electronics",19,5400.00,5],
    ["Proximity Sensor NPN","PS-NPN-M18","Electronics",420,185.00,100],
    ["Photoelectric Sensor","PES-DC24","Electronics",280,260.00,60],
    ["Encoder 1000 PPR","ENC-1000R","Electronics",110,920.00,20],
    ["Power Supply 24V 10A","PS-24V10A","Electronics",195,680.00,40],
    ["Relay Module 8ch","RM-8CH","Electronics",340,450.00,80],
    ["Temperature Controller PID","TC-PID","Electronics",88,1250.00,20],
    ["Load Cell 100kg","LC-100KG","Electronics",65,1800.00,15],
    ["Pressure Transmitter","PT-4-20MA","Electronics",55,2200.00,10],
    ["Level Sensor Ultrasonic","LSU-M30","Electronics",90,1450.00,20],
    ["Stepper Motor Nema23","SM-N23","Electronics",145,890.00,30],
    ["DC Motor 24V 100W","DCM-24V","Electronics",200,650.00,40],
    ["Solenoid Valve 24VDC","SV-24VDC","Electronics",310,380.00,60],
    ["Servo Drive 1.5kW","SD-1500W","Electronics",22,4800.00,5],
    ["Motion Controller 4-Axis","MC-4AX","Electronics",14,12500.00,3],
    ["Industrial Camera 5MP","IC-5MP","Electronics",30,8900.00,5],
    ["Barcode Scanner USB","BS-USB","Electronics",85,1200.00,15],
    // Fluids
    ["Hydraulic Fluid 46","HF-46L","Fluids",85,129.50,100],
    ["Grease Lithium EP2 5kg","GL-EP2-5","Fluids",320,450.00,80],
    ["Gear Oil SAE 90","GO-SAE90","Fluids",140,185.00,40],
    ["Coolant Concentrate 5L","CC-5L","Fluids",280,320.00,60],
    ["Penetrating Oil 500ml","PO-500ML","Fluids",850,85.00,200],
    ["Hydraulic Jack Oil 1L","HJO-1L","Fluids",190,145.00,50],
    ["Compressor Oil 10W30","CO-10W30","Fluids",110,220.00,30],
    ["Rust Preventive Spray","RPS-400","Fluids",560,95.00,150],
    ["Anti-Seize Compound 1kg","ASC-1KG","Fluids",200,280.00,50],
    ["Bearing Grease 500g","BG-500G","Fluids",450,155.00,100],
    ["Thread Sealing Compound","TSC-200","Fluids",300,125.00,80],
    ["Transformer Oil 20L","TO-20L","Fluids",75,890.00,20],
    ["Industrial Solvent IPA","ISI-5L","Fluids",240,340.00,60],
    ["Heat Transfer Oil","HTO-10L","Fluids",90,560.00,20],
    ["Silicone Grease 100g","SG-100G","Fluids",380,185.00,80],
    ["Chain Lubricant Spray","CLS-400","Fluids",490,75.00,100],
    ["Mold Release Agent","MRA-1L","Fluids",160,220.00,40],
    ["Brake Fluid DOT4","BF-DOT4","Fluids",220,185.00,60],
    ["Cutting Fluid 5L","CF-5L","Fluids",145,290.00,40],
    ["EP Additive 1L","EPA-1L","Fluids",195,340.00,50],
    // Safety
    ["Safety Helmets (Class E)","SH-CE-WHT","Safety",620,24.99,150],
    ["Nitrile Gloves (100pk)","NG-100-M","Safety",2100,18.75,500],
    ["Safety Goggles Anti-fog","SGA-AF","Safety",940,320.00,200],
    ["Ear Protection 30dB","EP-30DB","Safety",1200,145.00,300],
    ["High-Vis Vest Type 2","HVV-T2","Safety",780,285.00,150],
    ["Safety Shoes Steel Toe","SS-ST-42","Safety",340,1250.00,80],
    ["Fall Arrest Harness","FAH-200","Safety",150,3200.00,30],
    ["Fire Extinguisher 5kg","FE-5KG","Safety",280,1800.00,60],
    ["First Aid Kit 200pcs","FAK-200","Safety",180,850.00,40],
    ["Safety Gloves Cut 5","SGC-5L","Safety",600,380.00,120],
    ["Dust Mask N95 (50pk)","DM-N95","Safety",1500,450.00,300],
    ["Chemical Resistant Apron","CRA-PVC","Safety",240,680.00,50],
    ["Safety Boots Chemical","SBC-44","Safety",185,1450.00,40],
    ["Emergency Eye Wash","EEW-16","Safety",65,2800.00,15],
    ["Lockout Tagout Kit","LOTO-KIT","Safety",95,1200.00,20],
    ["Safety Line 10m","SL-10M","Safety",130,890.00,30],
    ["Gas Detector 4-in-1","GD-4X","Safety",45,8500.00,10],
    ["Reflective Tape 50m","RT-50M","Safety",200,350.00,50],
    ["Hard Hat Liner Winter","HHL-W","Safety",350,180.00,80],
    ["Face Shield Polycarbonate","FSP-250","Safety",420,350.00,100],
    // Tools
    ["Digital Torque Wrench","DTW-50NM","Tools",72,340.00,30],
    ["Angle Grinder 4.5\"","AG-4.5","Tools",180,2800.00,40],
    ["Bench Drill Press 350W","BDP-350","Tools",38,6500.00,8],
    ["Digital Caliper 150mm","DC-150","Tools",290,850.00,60],
    ["Hydraulic Press 10T","HP-10T","Tools",22,18500.00,5],
    ["Ratchet Socket Set 40pc","RSS-40","Tools",145,2200.00,30],
    ["Torque Screwdriver Set","TSS-20NM","Tools",98,1800.00,20],
    ["Laser Level 3-Beam","LL-3B","Tools",60,3200.00,15],
    ["Oscilloscope 100MHz","OSC-100M","Tools",18,24000.00,3],
    ["Wire Stripper Auto","WSA-25","Tools",240,450.00,50],
    ["Industrial Heat Gun","IHG-2000","Tools",88,1800.00,20],
    ["Pipe Bender Hydraulic","PBH-1.5","Tools",30,8500.00,5],
    ["Multimeter Digital True-RMS","MDT-RMS","Tools",175,1200.00,40],
    ["Magnetic Base Stand","MBS-150","Tools",120,680.00,30],
    ["Cable Crimper Ratchet","CCR-4-6","Tools",150,850.00,35],
    ["Tap & Die Set 40pc","TDS-40","Tools",65,3200.00,15],
    ["Digital Micrometer 25mm","DM-25","Tools",85,1450.00,20],
    ["Flux Core Welder 120A","FCW-120","Tools",45,12000.00,10],
    ["Pipe Wrench 24\"","PW-24","Tools",160,780.00,40],
    ["Soldering Station 60W","SS-60W","Tools",110,2200.00,25],
    // Other
    ["Packing Foam Sheet 2M","PFS-2M","Other",350,145.00,80],
    ["Cable Tie Assorted (500pk)","CTA-500","Other",800,185.00,200],
    ["Zip Lock Bag 12x10","ZLB-1210","Other",2000,45.00,500],
    ["Labels Self-Adhesive (1000pk)","LSA-1000","Other",600,220.00,150],
    ["Cardboard Boxes Large","CBL-50","Other",400,385.00,100],
    ["Stretch Wrap 500m","SW-500","Other",180,480.00,40],
    ["Bubble Wrap 50m","BW-50M","Other",140,520.00,30],
    ["Pallets Wooden 1200x1000","PW-1200","Other",120,780.00,25],
    ["Desiccant Silica Gel 1kg","DSG-1KG","Other",500,185.00,100],
    ["Strapping Band PP 12mm","SBP-12","Other",300,340.00,60]
  ];

  var whIds = ["WH-001","WH-002","WH-003","WH-004","WH-005"];
  var supIds = suppliers.map(function(s){ return s.supplier_id; });
  var dateOffset = 0;

  /* Generate 400 products by cycling through the 100 base items × 4 variant multiplier */
  for (var i = 0; i < 400; i++) {
    var base = prodData[i % prodData.length];
    var variantNum = Math.floor(i / prodData.length);
    var variantSuffixes = ["", " Pro", " Plus", " Industrial"];
    var variantSkuSuffixes = ["", "-P", "-L", "-I"];
    var pNum = i + 1;
    var pId = "PRD-" + (pNum < 10 ? "00" + pNum : pNum < 100 ? "0" + pNum : pNum);
    var baseDate = new Date("2024-01-01");
    baseDate.setDate(baseDate.getDate() + (i * 2) % 365);
    var yr = baseDate.getFullYear();
    var mo = String(baseDate.getMonth()+1).padStart(2,"0");
    var da = String(baseDate.getDate()).padStart(2,"0");
    products.push({
      product_id: pId,
      name: base[0] + variantSuffixes[variantNum],
      sku: base[1] + variantSkuSuffixes[variantNum] + (variantNum > 0 ? "-" + pNum : ""),
      category: base[2],
      qty: Math.max(0, Math.round(base[3] * (0.6 + (i % 7) * 0.1))),
      price: Math.round(base[4] * (1 + (i % 5) * 0.05) * 100) / 100,
      reorder: base[5],
      warehouse_id: whIds[i % 5],
      supplier_id: supIds[i % 30],
      created: yr + "-" + mo + "-" + da
    });
  }

  var purchase_orders = [
    { po_id:"PO-2024-001", product_id:"PRD-002", supplier_id:"SUP-001", qty:200,  price:25900,  status:"Completed",  order_date:"2024-03-10", delivery_date:"2024-03-18" },
    { po_id:"PO-2024-002", product_id:"PRD-021", supplier_id:"SUP-003", qty:15,   price:21750,  status:"In Transit",  order_date:"2024-03-28", delivery_date:"2024-04-05" },
    { po_id:"PO-2024-003", product_id:"PRD-001", supplier_id:"SUP-001", qty:500,  price:22995,  status:"Pending",     order_date:"2024-04-02", delivery_date:"2024-04-15" },
    { po_id:"PO-2024-004", product_id:"PRD-062", supplier_id:"SUP-004", qty:1000, price:18750,  status:"Completed",   order_date:"2024-02-20", delivery_date:"2024-02-27" },
    { po_id:"PO-2024-005", product_id:"PRD-041", supplier_id:"SUP-002", qty:50,   price:6475,   status:"Pending",     order_date:"2024-04-05", delivery_date:"2024-04-20" },
    { po_id:"PO-2024-006", product_id:"PRD-085", supplier_id:"SUP-005", qty:30,   price:10200,  status:"In Transit",  order_date:"2024-04-08", delivery_date:"2024-04-18" }
  ];

  var sales_orders = [
    { so_id:"SO-2024-001", product_id:"PRD-001", customer:"TechBuild Corp",   qty:50,  price:2524.45, status:"Completed",  sale_date:"2024-03-15" },
    { so_id:"SO-2024-002", product_id:"PRD-061", customer:"SafeWork Ltd",     qty:80,  price:2198.12, status:"Dispatched",  sale_date:"2024-03-30" },
    { so_id:"SO-2024-003", product_id:"PRD-081", customer:"AutoFab India",    qty:10,  price:3740.00, status:"Processing",  sale_date:"2024-04-03" },
    { so_id:"SO-2024-004", product_id:"PRD-021", customer:"Robolink Systems", qty:5,   price:4834.50, status:"Completed",   sale_date:"2024-02-25" },
    { so_id:"SO-2024-005", product_id:"PRD-041", customer:"IndusMart Pvt.",   qty:20,  price:2849.00, status:"Processing",  sale_date:"2024-04-10" }
  ];

  return { warehouses:warehouses, suppliers:suppliers, products:products, purchase_orders:purchase_orders, sales_orders:sales_orders };
}());

/* ── DATABASE ENGINE ─────────────────────────────────────── */
var DB = (function(){
  var LS = 'invenpro_v3';
  var _d = null;

  function load(){
    try {
      var s = localStorage.getItem(LS);
      if(s){ _d = JSON.parse(s); }
      else { _d = JSON.parse(JSON.stringify(SEED)); save(); }
    } catch(e) { _d = JSON.parse(JSON.stringify(SEED)); }
  }

  function save(){
    try { localStorage.setItem(LS, JSON.stringify(_d)); } catch(e){}
  }

  function clone(x){ return JSON.parse(JSON.stringify(x)); }

  return {
    init: load,
    all: function(t){ return clone(_d[t]||[]); },
    byId: function(t,k,id){ var r=_d[t].find(function(x){return x[k]===id;}); return r?clone(r):null; },
    exists: function(t,k,id){ return _d[t].some(function(x){return x[k]===id;}); },
    add: function(t,rec){ _d[t].unshift(clone(rec)); save(); },
    update: function(t,k,id,patch){
      var i=_d[t].findIndex(function(x){return x[k]===id;});
      if(i<0) return false;
      Object.assign(_d[t][i], patch);
      save(); return true;
    },
    remove: function(t,k,id){
      var before=_d[t].length;
      _d[t]=_d[t].filter(function(x){return x[k]!==id;});
      save(); return _d[t].length<before;
    },
    reset: function(){
      _d = JSON.parse(JSON.stringify(SEED));
      save();
    }
  };
}());

/* ── UTILITIES ───────────────────────────────────────────── */
function currency(n){ return '₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2}); }
function fdate(d){ if(!d) return '—'; var dt=new Date(d); return isNaN(dt)?d:dt.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}); }
function todayStr(){ var d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function uid(prefix){ return prefix+'-'+Date.now().toString(36).toUpperCase().slice(-6); }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function q(sel){ return document.querySelector(sel); }
function qa(sel){ return Array.from(document.querySelectorAll(sel)); }
function val(id){ var el=document.getElementById(id); return el?(el.value||'').trim():''; }
function numVal(id){ return parseFloat(val(id))||0; }
function intVal(id){ return parseInt(val(id))||0; }

function stockClass(qty,reorder){ if(qty<=0) return 'crit'; if(qty<=reorder) return 'low'; return 'good'; }
function stockBadge(qty,reorder){
  var c=stockClass(qty,reorder);
  var map={good:['bg-green','In Stock'],low:['bg-yellow','Low Stock'],crit:['bg-red','Out of Stock']};
  return '<span class="badge '+map[c][0]+'">'+map[c][1]+'</span>';
}
function statusBadge(s){
  var map={'Delivered':'bg-green','Completed':'bg-green','In Transit':'bg-cyan','Dispatched':'bg-cyan','Pending':'bg-yellow','Processing':'bg-yellow','Cancelled':'bg-red'};
  return '<span class="badge '+(map[s]||'bg-purple')+'">'+esc(s)+'</span>';
}
function stars(r){
  var n=Math.round(r*2)/2, full=Math.floor(n), half=n%1?1:0;
  return '<span class="stars">'+'★'.repeat(full)+(half?'½':'')+'☆'.repeat(5-full-half)+'</span> <span style="color:var(--t2);font-size:.75rem">'+r+'</span>';
}
function filter(rows,q2,fields){
  if(!q2) return rows;
  q2=q2.toLowerCase();
  return rows.filter(function(r){ return fields.some(function(f){ return String(r[f]||'').toLowerCase().includes(q2); }); });
}

/* ── TOAST ───────────────────────────────────────────────── */
var Toast = (function(){
  var icons={success:'✅',error:'❌',warning:'⚠️',info:'ℹ️'};
  var colors={success:'var(--green)',error:'var(--red)',warning:'var(--yellow)',info:'var(--cyan)'};
  return {
    show: function(msg,type){
      type=type||'success';
      var t=document.createElement('div');
      t.className='toast';
      t.style.setProperty('--tc', colors[type]||colors.info);
      t.innerHTML='<span class="ti">'+icons[type]+'</span><span class="tm">'+esc(msg)+'</span>';
      q('#toasts').appendChild(t);
      setTimeout(function(){ t.classList.add('out'); setTimeout(function(){ t.remove(); },300); }, 3500);
    }
  };
}());

/* ── MODAL ───────────────────────────────────────────────── */
var Modal = (function(){
  var bg, title, body, footer;
  function init(){
    bg    =q('#modal-bg');
    title =q('#modal-title');
    body  =q('#modal-body');
    footer=q('#modal-footer');
    bg.addEventListener('click', function(e){ if(e.target===bg) close(); });
    q('#modal-x').addEventListener('click', close);
  }
  function open(cfg){ title.textContent=cfg.title||''; body.innerHTML=cfg.body||''; footer.innerHTML=cfg.footer||''; bg.classList.add('open'); }
  function close(){ bg.classList.remove('open'); }
  return { init:init, open:open, close:close };
}());

/* ── NAVIGATION ──────────────────────────────────────────── */
var Nav = (function(){
  var current=null;
  var pages={
    dashboard:       {title:'Dashboard',       sub:'Overview & Analytics'},
    products:        {title:'Products',        sub:'Manage Inventory Items'},
    suppliers:       {title:'Suppliers',       sub:'Manage Suppliers'},
    warehouses:      {title:'Warehouses',      sub:'Manage Storage Facilities'},
    purchase_orders: {title:'Purchase Orders', sub:'Inbound Stock Orders'},
    sales_orders:    {title:'Sales Orders',    sub:'Outbound Sales Records'}
  };
  var renderers={};

  function go(id){
    if(current===id) return;
    qa('.page').forEach(function(p){ p.classList.remove('active'); });
    qa('.nav-item[data-page]').forEach(function(n){ n.classList.remove('active'); });
    var pg=q('#pg-'+id);
    if(!pg){ return; }
    pg.classList.add('active');
    var ni=q('.nav-item[data-page="'+id+'"]');
    if(ni) ni.classList.add('active');
    var info=pages[id]||{};
    q('#tb-title').textContent=info.title||id;
    q('#tb-sub').textContent=info.sub||'';
    current=id;
    q('#g-search').value='';
    if(renderers[id]) renderers[id]();
  }

  function register(id,fn){ renderers[id]=fn; }
  function getCurrent(){ return current; }
  return { go:go, register:register, getCurrent:getCurrent };
}());

/* ── DASHBOARD ───────────────────────────────────────────── */
function renderDashboard(){
  var prods=DB.all('products'), sups=DB.all('suppliers'), whs=DB.all('warehouses');
  var pos=DB.all('purchase_orders'), sos=DB.all('sales_orders');
  var totalVal=prods.reduce(function(s,p){ return s+(p.qty*p.price); },0);
  var lowStock=prods.filter(function(p){ return stockClass(p.qty,p.reorder)!=='good'; });
  var pendingPO=pos.filter(function(o){ return o.status==='Pending'||o.status==='In Transit'; });
  var salesVal=sos.filter(function(o){ return o.status==='Completed'; }).reduce(function(s,o){ return s+o.price; },0);

  q('#d-prods').textContent=prods.length;
  q('#d-val').textContent=currency(totalVal);
  q('#d-low').textContent=lowStock.length;
  q('#d-ppo').textContent=pendingPO.length;
  q('#d-sales').textContent=currency(salesVal);
  q('#d-sups').textContent=sups.length;

  qa('.nav-badge').forEach(function(b){ b.textContent=lowStock.length||''; b.style.display=lowStock.length?'':'none'; });

  var whHtml=whs.map(function(w){
    var pct=Math.min(100,Math.round((w.used/w.capacity)*100));
    var col=pct>85?'var(--red)':pct>60?'var(--yellow)':'var(--green)';
    return '<div class="mbar-item"><div class="mbar-lbl"><span>'+esc(w.name)+'</span><span>'+pct+'%</span></div>'+
      '<div class="mbar-track"><div class="mbar-fill" style="width:'+pct+'%;background:'+col+'"></div></div></div>';
  }).join('');
  q('#d-wh-bars').innerHTML=whHtml||'<p style="color:var(--t3);font-size:.85rem">No warehouses.</p>';

  var alertHtml=lowStock.length===0
    ?'<div class="alert-ok"><span>✅</span><span>All stock levels healthy — no alerts!</span></div>'
    :lowStock.slice(0,6).map(function(p){
        return '<div class="alert-row">'+
          '<span class="ar-dot">'+(p.qty<=0?'🔴':'🟡')+'</span>'+
          '<div class="ar-info"><div class="ar-name">'+esc(p.name)+'</div>'+
          '<div class="ar-sub">Qty: <strong>'+p.qty+'</strong> · Reorder at: '+p.reorder+'</div></div>'+
          '<div class="ar-id">'+esc(p.product_id)+'</div></div>';
      }).join('');
  q('#d-alerts').innerHTML='<div class="alert-list">'+alertHtml+'</div>';

  var cats={};
  prods.forEach(function(p){ cats[p.category]=(cats[p.category]||0)+1; });
  var total=prods.length||1;
  var catColors=['var(--cyan)','var(--orange)','var(--green)','var(--purple)','var(--yellow)','var(--red)'];
  var catHtml=Object.keys(cats).map(function(k,i){
    var pct=Math.round((cats[k]/total)*100);
    return '<div class="mbar-item"><div class="mbar-lbl"><span>'+esc(k)+'</span><span>'+cats[k]+' items ('+pct+'%)</span></div>'+
      '<div class="mbar-track"><div class="mbar-fill" style="width:'+pct+'%;background:'+catColors[i%catColors.length]+'"></div></div></div>';
  }).join('');
  q('#d-cat-bars').innerHTML=catHtml||'<p style="color:var(--t3);font-size:.85rem">No data.</p>';

  var all=[].concat(
    pos.map(function(o){ return {id:o.po_id,type:'📥 Purchase',prod:o.product_id,date:o.order_date,price:o.price,status:o.status}; }),
    sos.map(function(o){ return {id:o.so_id,type:'📤 Sales',prod:o.product_id,date:o.sale_date,price:o.price,status:o.status}; })
  );
  all.sort(function(a,b){ return new Date(b.date)-new Date(a.date); });
  var recent=all.slice(0,8);
  var recHtml=recent.length===0
    ?'<tr><td colspan="6" class="empty-row"><span class="ei">📋</span>No orders yet</td></tr>'
    :recent.map(function(o){
        return '<tr><td class="td-id">'+esc(o.id)+'</td><td>'+o.type+'</td><td class="td-id">'+esc(o.prod)+'</td>'+
          '<td>'+fdate(o.date)+'</td><td>'+currency(o.price)+'</td><td>'+statusBadge(o.status)+'</td></tr>';
      }).join('');
  q('#d-recent').innerHTML=recHtml;
}

/* ── PRODUCTS ────────────────────────────────────────────── */
var Products = (function(){
  var _filter='';
  var CATS=['Mechanical','Electronics','Fluids','Safety','Tools','Other'];

  function render(){ _renderTable(DB.all('products')); }

  function _renderTable(rows){
    var f=filter(rows,_filter,['product_id','name','category','sku','warehouse_id','supplier_id']);
    var html;
    if(!f.length){
      html='<tr><td colspan="9" class="empty-row"><span class="ei">📦</span>No products found</td></tr>';
    } else {
      html=f.map(function(p){
        var sc=stockClass(p.qty,p.reorder);
        return '<tr>'+
          '<td class="td-id">'+esc(p.product_id)+'</td>'+
          '<td><strong>'+esc(p.name)+'</strong><br><span class="sku-tag">'+esc(p.sku)+'</span></td>'+
          '<td><span class="badge bg-purple">'+esc(p.category)+'</span></td>'+
          '<td><span class="sdot '+sc+'">'+p.qty.toLocaleString()+'</span></td>'+
          '<td class="price-cell">'+currency(p.price)+'</td>'+
          '<td class="price-cell">'+currency(p.qty*p.price)+'</td>'+
          '<td class="td-id">'+esc(p.warehouse_id||'—')+'</td>'+
          '<td>'+stockBadge(p.qty,p.reorder)+'</td>'+
          '<td><div class="td-act">'+
            '<button class="btn btn-warning btn-sm btn-ico" onclick="Products.edit(\''+esc(p.product_id)+'\')">✏️</button>'+
            '<button class="btn btn-danger btn-sm btn-ico" onclick="Products.del(\''+esc(p.product_id)+'\')">🗑️</button>'+
          '</div></td></tr>';
      }).join('');
    }
    q('#p-tbody').innerHTML=html;
    q('#p-count').textContent=f.length+' of '+rows.length+' products';
  }

  function openAdd(){
    var whOpts=DB.all('warehouses').map(function(w){ return '<option value="'+esc(w.warehouse_id)+'">'+esc(w.warehouse_id)+' — '+esc(w.name)+'</option>'; }).join('');
    var supOpts=DB.all('suppliers').map(function(s){ return '<option value="'+esc(s.supplier_id)+'">'+esc(s.supplier_id)+' — '+esc(s.name)+'</option>'; }).join('');
    var catOpts=CATS.map(function(c){ return '<option>'+c+'</option>'; }).join('');
    Modal.open({
      title:'➕ Add New Product',
      body:'<div class="fgrid">'+
        '<div class="fgrp"><label class="flbl">Product ID *</label><input id="m-pid" class="finp" placeholder="PRD-401"></div>'+
        '<div class="fgrp"><label class="flbl">SKU *</label><input id="m-sku" class="finp" placeholder="ABC-1234"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Product Name *</label><input id="m-name" class="finp" placeholder="Full product name"></div>'+
        '<div class="fgrp"><label class="flbl">Category</label><select id="m-cat" class="finp">'+catOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Warehouse</label><select id="m-wh" class="finp"><option value="">— None —</option>'+whOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Quantity *</label><input id="m-qty" class="finp" type="number" min="0" placeholder="0"></div>'+
        '<div class="fgrp"><label class="flbl">Unit Price (₹) *</label><input id="m-price" class="finp" type="number" min="0" step="0.01" placeholder="0.00"></div>'+
        '<div class="fgrp"><label class="flbl">Reorder Level</label><input id="m-reorder" class="finp" type="number" min="0" value="50"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Supplier</label><select id="m-sup" class="finp"><option value="">— None —</option>'+supOpts+'</select></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Products.save()">💾 Save Product</button>'
    });
  }

  function save(){
    var pid=val('m-pid'), name=val('m-name'), sku=val('m-sku');
    var qty=intVal('m-qty'), price=numVal('m-price');
    if(!pid||!name||!sku){ Toast.show('Product ID, Name & SKU are required','error'); return; }
    if(DB.exists('products','product_id',pid)){ Toast.show('Product ID already exists!','error'); return; }
    DB.add('products',{ product_id:pid, name:name, sku:sku, category:val('m-cat'), qty:qty, price:price, reorder:intVal('m-reorder')||50, warehouse_id:val('m-wh'), supplier_id:val('m-sup'), created:todayStr() });
    Modal.close(); render(); renderDashboard();
    Toast.show('Product "'+name+'" added!');
  }

  function edit(id){
    var p=DB.byId('products','product_id',id); if(!p) return;
    var whOpts=DB.all('warehouses').map(function(w){ return '<option value="'+esc(w.warehouse_id)+'"'+(w.warehouse_id===p.warehouse_id?' selected':'')+'>'+esc(w.warehouse_id)+' — '+esc(w.name)+'</option>'; }).join('');
    var catOpts=CATS.map(function(c){ return '<option'+(c===p.category?' selected':'')+'>'+c+'</option>'; }).join('');
    var supOpts=DB.all('suppliers').map(function(s){ return '<option value="'+esc(s.supplier_id)+'"'+(s.supplier_id===p.supplier_id?' selected':'')+'>'+esc(s.supplier_id)+' — '+esc(s.name)+'</option>'; }).join('');
    Modal.open({
      title:'✏️ Edit Product — '+esc(id),
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Product Name</label><input id="e-name" class="finp" value="'+esc(p.name)+'"></div>'+
        '<div class="fgrp"><label class="flbl">SKU</label><input id="e-sku" class="finp" value="'+esc(p.sku)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Category</label><select id="e-cat" class="finp">'+catOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Quantity</label><input id="e-qty" class="finp" type="number" min="0" value="'+p.qty+'"></div>'+
        '<div class="fgrp"><label class="flbl">Unit Price (₹)</label><input id="e-price" class="finp" type="number" step="0.01" value="'+p.price+'"></div>'+
        '<div class="fgrp"><label class="flbl">Reorder Level</label><input id="e-reorder" class="finp" type="number" value="'+p.reorder+'"></div>'+
        '<div class="fgrp"><label class="flbl">Warehouse</label><select id="e-wh" class="finp"><option value="">— None —</option>'+whOpts+'</select></div>'+
        '<div class="fgrp fspan"><label class="flbl">Supplier</label><select id="e-sup" class="finp"><option value="">— None —</option>'+supOpts+'</select></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Products.update(\''+esc(id)+'\')">💾 Update</button>'
    });
  }

  function update(id){
    var name=val('e-name');
    if(!name){ Toast.show('Name is required','error'); return; }
    DB.update('products','product_id',id,{ name:name, sku:val('e-sku'), category:val('e-cat'), qty:intVal('e-qty'), price:numVal('e-price'), reorder:intVal('e-reorder')||50, warehouse_id:val('e-wh'), supplier_id:val('e-sup') });
    Modal.close(); render(); renderDashboard();
    Toast.show('Product updated!');
  }

  function del(id){
    _confirm('Product', id, function(){ DB.remove('products','product_id',id); render(); renderDashboard(); Toast.show('Product '+id+' deleted','warning'); });
  }

  function setFilter(s){ _filter=s; _renderTable(DB.all('products')); }
  return { render:render, openAdd:openAdd, save:save, edit:edit, update:update, del:del, setFilter:setFilter };
}());

/* ── SUPPLIERS ───────────────────────────────────────────── */
var Suppliers = (function(){
  var _filter='';

  function render(){ _renderTable(DB.all('suppliers')); }

  function _renderTable(rows){
    var f=filter(rows,_filter,['supplier_id','name','contact','email','address','phone']);
    var html;
    if(!f.length){
      html='<tr><td colspan="7" class="empty-row"><span class="ei">🏭</span>No suppliers found</td></tr>';
    } else {
      html=f.map(function(s){
        return '<tr>'+
          '<td class="td-id">'+esc(s.supplier_id)+'</td>'+
          '<td><strong>'+esc(s.name)+'</strong><br><span style="font-size:.75rem;color:var(--t3)">'+esc(s.contact)+'</span></td>'+
          '<td>'+esc(s.phone)+'</td>'+
          '<td style="font-size:.8rem"><a href="mailto:'+esc(s.email)+'" style="color:var(--primary);text-decoration:none">'+esc(s.email)+'</a></td>'+
          '<td style="font-size:.78rem;color:var(--t2)">📍 '+esc(s.address)+'</td>'+
          '<td>'+stars(s.rating)+'</td>'+
          '<td><div class="td-act">'+
            '<button class="btn btn-warning btn-sm btn-ico" onclick="Suppliers.edit(\''+esc(s.supplier_id)+'\')">✏️</button>'+
            '<button class="btn btn-danger btn-sm btn-ico" onclick="Suppliers.del(\''+esc(s.supplier_id)+'\')">🗑️</button>'+
          '</div></td></tr>';
      }).join('');
    }
    q('#s-tbody').innerHTML=html;
    q('#s-count').textContent=f.length+' of '+rows.length+' suppliers';
  }

  function openAdd(){
    Modal.open({
      title:'➕ Add Supplier',
      body:'<div class="fgrid">'+
        '<div class="fgrp"><label class="flbl">Supplier ID *</label><input id="m-sid" class="finp" placeholder="SUP-031"></div>'+
        '<div class="fgrp"><label class="flbl">Rating (1–5)</label><input id="m-rating" class="finp" type="number" min="1" max="5" step="0.1" value="4.0"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Company Name *</label><input id="m-sname" class="finp" placeholder="Company name"></div>'+
        '<div class="fgrp"><label class="flbl">Contact Person</label><input id="m-contact" class="finp" placeholder="Full name"></div>'+
        '<div class="fgrp"><label class="flbl">Phone *</label><input id="m-phone" class="finp" placeholder="+91-XXXXXXXXXX"></div>'+
        '<div class="fgrp"><label class="flbl">Email</label><input id="m-email" class="finp" type="email" placeholder="email@company.com"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Address</label><input id="m-addr" class="finp" placeholder="Full address"></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Suppliers.save()">💾 Save</button>'
    });
  }

  function save(){
    var sid=val('m-sid'), name=val('m-sname'), phone=val('m-phone');
    if(!sid||!name||!phone){ Toast.show('ID, Name & Phone are required','error'); return; }
    if(DB.exists('suppliers','supplier_id',sid)){ Toast.show('Supplier ID already exists!','error'); return; }
    DB.add('suppliers',{ supplier_id:sid, name:name, contact:val('m-contact'), phone:phone, email:val('m-email'), address:val('m-addr'), rating:parseFloat(val('m-rating'))||4.0, created:todayStr() });
    Modal.close(); render(); renderDashboard();
    Toast.show('Supplier "'+name+'" added!');
  }

  function edit(id){
    var s=DB.byId('suppliers','supplier_id',id); if(!s) return;
    Modal.open({
      title:'✏️ Edit Supplier — '+esc(id),
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Company Name</label><input id="e-sname" class="finp" value="'+esc(s.name)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Contact Person</label><input id="e-contact" class="finp" value="'+esc(s.contact)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Phone</label><input id="e-phone" class="finp" value="'+esc(s.phone)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Email</label><input id="e-email" class="finp" value="'+esc(s.email)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Rating</label><input id="e-rating" class="finp" type="number" min="1" max="5" step="0.1" value="'+s.rating+'"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Address</label><input id="e-addr" class="finp" value="'+esc(s.address)+'"></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Suppliers.update(\''+esc(id)+'\')">💾 Update</button>'
    });
  }

  function update(id){
    DB.update('suppliers','supplier_id',id,{ name:val('e-sname'), contact:val('e-contact'), phone:val('e-phone'), email:val('e-email'), rating:parseFloat(val('e-rating'))||4.0, address:val('e-addr') });
    Modal.close(); render();
    Toast.show('Supplier updated!');
  }

  function del(id){
    _confirm('Supplier', id, function(){ DB.remove('suppliers','supplier_id',id); render(); renderDashboard(); Toast.show('Supplier '+id+' deleted','warning'); });
  }

  function setFilter(s){ _filter=s; _renderTable(DB.all('suppliers')); }
  return { render:render, openAdd:openAdd, save:save, edit:edit, update:update, del:del, setFilter:setFilter };
}());

/* ── WAREHOUSES ──────────────────────────────────────────── */
var Warehouses = (function(){
  var _filter='';

  function render(){ _renderCards(DB.all('warehouses')); }

  function _renderCards(rows){
    var f=filter(rows,_filter,['warehouse_id','name','location','manager']);
    var html;
    if(!f.length){
      html='<div class="empty-row"><span class="ei">🏪</span>No warehouses found</div>';
    } else {
      html=f.map(function(w){
        var pct=Math.min(100,Math.round((w.used/w.capacity)*100));
        var col=pct>85?'var(--red)':pct>60?'var(--yellow)':'var(--green)';
        var badge=pct>85?'bg-red':pct>60?'bg-yellow':'bg-green';
        var label=pct>85?'Near Full':pct>60?'Moderate':'Available';
        return '<div class="wh-card">'+
          '<div class="wh-card-hd"><div class="wh-icon">🏪</div><div><h3>'+esc(w.name)+'</h3><div class="td-id" style="font-size:.75rem">'+esc(w.warehouse_id)+'</div></div><span class="badge '+badge+'">'+label+'</span></div>'+
          '<div class="wh-card-body">'+
            '<div class="wh-meta">'+
              '<div class="wh-meta-row"><span class="wh-lbl">📍 Location</span><span>'+esc(w.location)+'</span></div>'+
              '<div class="wh-meta-row"><span class="wh-lbl">👤 Manager</span><span>'+esc(w.manager)+'</span></div>'+
              '<div class="wh-meta-row"><span class="wh-lbl">📞 Phone</span><span>'+esc(w.phone||'—')+'</span></div>'+
              '<div class="wh-meta-row"><span class="wh-lbl">📅 Since</span><span>'+fdate(w.created)+'</span></div>'+
            '</div>'+
            '<div class="wh-bar-wrap">'+
              '<div class="wh-bar-lbl"><span>Capacity Used</span><span style="color:'+col+';font-weight:600">'+pct+'% ('+w.used.toLocaleString()+' / '+w.capacity.toLocaleString()+')</span></div>'+
              '<div class="wh-bar-track"><div class="wh-bar-fill" style="width:'+pct+'%;background:'+col+'"></div></div>'+
            '</div>'+
            '<div class="wh-actions">'+
              '<button class="btn btn-warning btn-sm" onclick="Warehouses.edit(\''+esc(w.warehouse_id)+'\')">✏️ Edit</button>'+
              '<button class="btn btn-danger btn-sm" onclick="Warehouses.del(\''+esc(w.warehouse_id)+'\')">🗑️ Delete</button>'+
            '</div>'+
          '</div></div>';
      }).join('');
    }
    q('#wh-grid').innerHTML=html;
  }

  function openAdd(){
    Modal.open({
      title:'➕ Add Warehouse',
      body:'<div class="fgrid">'+
        '<div class="fgrp"><label class="flbl">Warehouse ID *</label><input id="m-wid" class="finp" placeholder="WH-006"></div>'+
        '<div class="fgrp"><label class="flbl">Manager</label><input id="m-wmgr" class="finp" placeholder="Manager name"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Name *</label><input id="m-wname" class="finp" placeholder="Warehouse name"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Location *</label><input id="m-wloc" class="finp" placeholder="Full address"></div>'+
        '<div class="fgrp"><label class="flbl">Total Capacity</label><input id="m-wcap" class="finp" type="number" value="3000" min="0"></div>'+
        '<div class="fgrp"><label class="flbl">Used Capacity</label><input id="m-wused" class="finp" type="number" value="0" min="0"></div>'+
        '<div class="fgrp"><label class="flbl">Phone</label><input id="m-wphone" class="finp" placeholder="000-00000000"></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Warehouses.save()">💾 Save</button>'
    });
  }

  function save(){
    var wid=val('m-wid'), name=val('m-wname'), loc=val('m-wloc');
    if(!wid||!name||!loc){ Toast.show('ID, Name & Location are required','error'); return; }
    if(DB.exists('warehouses','warehouse_id',wid)){ Toast.show('Warehouse ID already exists!','error'); return; }
    DB.add('warehouses',{ warehouse_id:wid, name:name, location:loc, manager:val('m-wmgr'), capacity:intVal('m-wcap')||3000, used:intVal('m-wused')||0, phone:val('m-wphone'), created:todayStr() });
    Modal.close(); render(); renderDashboard();
    Toast.show('Warehouse "'+name+'" added!');
  }

  function edit(id){
    var w=DB.byId('warehouses','warehouse_id',id); if(!w) return;
    Modal.open({
      title:'✏️ Edit Warehouse — '+esc(id),
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Name</label><input id="e-wname" class="finp" value="'+esc(w.name)+'"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Location</label><input id="e-wloc" class="finp" value="'+esc(w.location)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Manager</label><input id="e-wmgr" class="finp" value="'+esc(w.manager||'')+'"></div>'+
        '<div class="fgrp"><label class="flbl">Phone</label><input id="e-wphone" class="finp" value="'+esc(w.phone||'')+'"></div>'+
        '<div class="fgrp"><label class="flbl">Total Capacity</label><input id="e-wcap" class="finp" type="number" value="'+w.capacity+'"></div>'+
        '<div class="fgrp"><label class="flbl">Used Capacity</label><input id="e-wused" class="finp" type="number" value="'+w.used+'"></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="Warehouses.update(\''+esc(id)+'\')">💾 Update</button>'
    });
  }

  function update(id){
    DB.update('warehouses','warehouse_id',id,{ name:val('e-wname'), location:val('e-wloc'), manager:val('e-wmgr'), phone:val('e-wphone'), capacity:intVal('e-wcap')||3000, used:intVal('e-wused')||0 });
    Modal.close(); render(); renderDashboard();
    Toast.show('Warehouse updated!');
  }

  function del(id){
    _confirm('Warehouse', id, function(){ DB.remove('warehouses','warehouse_id',id); render(); renderDashboard(); Toast.show('Warehouse '+id+' deleted','warning'); });
  }

  function setFilter(s){ _filter=s; _renderCards(DB.all('warehouses')); }
  return { render:render, openAdd:openAdd, save:save, edit:edit, update:update, del:del, setFilter:setFilter };
}());

/* ── PURCHASE ORDERS ─────────────────────────────────────── */
var PurchaseOrders = (function(){
  var _filter='';
  var STATUSES=['Pending','In Transit','Completed','Cancelled'];

  function render(){ _renderTable(DB.all('purchase_orders')); }

  function _renderTable(rows){
    var f=filter(rows,_filter,['po_id','product_id','supplier_id','status']);
    var html;
    if(!f.length){
      html='<tr><td colspan="9" class="empty-row"><span class="ei">📥</span>No purchase orders found</td></tr>';
    } else {
      var prods=DB.all('products');
      html=f.map(function(o){
        var prod=prods.find(function(p){return p.product_id===o.product_id;});
        var pname=prod?prod.name:'Unknown';
        return '<tr>'+
          '<td class="td-id">'+esc(o.po_id)+'</td>'+
          '<td><span class="td-id">'+esc(o.product_id)+'</span><br><span style="font-size:.75rem;color:var(--t2)">'+esc(pname)+'</span></td>'+
          '<td class="td-id">'+esc(o.supplier_id)+'</td>'+
          '<td style="font-family:var(--ff-mono);font-weight:600">'+o.qty.toLocaleString()+'</td>'+
          '<td class="price-cell">'+currency(o.price)+'</td>'+
          '<td style="font-size:.8rem;color:var(--t2)">'+currency(o.price/o.qty)+' / unit</td>'+
          '<td>'+fdate(o.order_date)+'</td>'+
          '<td>'+statusBadge(o.status)+'</td>'+
          '<td><div class="td-act">'+
            '<button class="btn btn-warning btn-sm btn-ico" onclick="PurchaseOrders.edit(\''+esc(o.po_id)+'\')">✏️</button>'+
            '<button class="btn btn-danger btn-sm btn-ico" onclick="PurchaseOrders.del(\''+esc(o.po_id)+'\')">🗑️</button>'+
          '</div></td></tr>';
      }).join('');
    }
    q('#po-tbody').innerHTML=html;
    q('#po-count').textContent=f.length+' orders';
  }

  function openAdd(){
    var pOpts=DB.all('products').map(function(p){
      return '<option value="'+esc(p.product_id)+'">'+esc(p.product_id)+' — '+esc(p.name)+' (Stock: '+p.qty+', ₹'+p.price+')</option>';
    }).join('');
    var sOpts=DB.all('suppliers').map(function(s){
      return '<option value="'+esc(s.supplier_id)+'">'+esc(s.supplier_id)+' — '+esc(s.name)+'</option>';
    }).join('');
    var stOpts=STATUSES.map(function(s){ return '<option>'+s+'</option>'; }).join('');
    Modal.open({
      title:'📥 Create Purchase Order',
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Product *</label>'+
          '<select id="m-prod" class="finp" onchange="PurchaseOrders._onProductChange()"><option value="">— Select Product —</option>'+pOpts+'</select></div>'+
        '<div class="fgrp fspan"><label class="flbl">Supplier *</label><select id="m-sup" class="finp"><option value="">— Select Supplier —</option>'+sOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Quantity *</label><input id="m-qty" class="finp" type="number" min="1" placeholder="0" oninput="PurchaseOrders._calcTotal()"></div>'+
        '<div class="fgrp"><label class="flbl">Unit Price (₹) — Auto</label><input id="m-unitprice" class="finp" type="text" readonly style="background:var(--bg2);cursor:not-allowed" placeholder="Select product first"></div>'+
        '<div class="fgrp fspan"><label class="flbl" style="color:var(--primary);font-weight:700">Total Price (₹) — Auto Calculated</label>'+
          '<input id="m-price" class="finp" type="text" readonly style="background:var(--bg2);cursor:not-allowed;font-weight:700;font-size:1rem" placeholder="0.00"></div>'+
        '<div class="fgrp"><label class="flbl">Status</label><select id="m-status" class="finp">'+stOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Order Date</label><input id="m-odate" class="finp" type="date" value="'+todayStr()+'"></div>'+
        '<div class="fgrp"><label class="flbl">Expected Delivery</label><input id="m-ddate" class="finp" type="date"></div>'+
        '<div class="fgrp fspan"><div class="info-box">ℹ️ Price is automatically set based on product\'s unit price × quantity. Stock will increase <strong>only when status = Completed</strong>.</div></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="PurchaseOrders.save()">💾 Create PO</button>'
    });
  }

  function _onProductChange(){
    var pid=val('m-prod');
    var upEl=document.getElementById('m-unitprice');
    var tpEl=document.getElementById('m-price');
    if(!pid){ if(upEl) upEl.value=''; if(tpEl) tpEl.value=''; return; }
    var p=DB.byId('products','product_id',pid);
    if(p){
      if(upEl) upEl.value='₹'+p.price.toFixed(2);
      _calcTotal();
    }
  }

  function _calcTotal(){
    var pid=val('m-prod');
    var qty=intVal('m-qty');
    var tpEl=document.getElementById('m-price');
    if(!pid||!qty){ if(tpEl) tpEl.value=''; return; }
    var p=DB.byId('products','product_id',pid);
    if(p && tpEl) tpEl.value='₹'+(p.price*qty).toFixed(2);
  }

  function save(){
    var prod=val('m-prod'), sup=val('m-sup');
    var qty=intVal('m-qty');
    var status=val('m-status');
    if(!prod||!sup||!qty){ Toast.show('Product, Supplier & Quantity are required','error'); return; }
    var p=DB.byId('products','product_id',prod);
    if(!p){ Toast.show('Product not found!','error'); return; }
    var totalPrice=Math.round(p.price*qty*100)/100;
    var id=uid('PO');
    DB.add('purchase_orders',{ po_id:id, product_id:prod, supplier_id:sup, qty:qty, price:totalPrice, status:status, order_date:val('m-odate'), delivery_date:val('m-ddate') });
    /* Stock increases ONLY when status = Completed */
    if(status==='Completed'){
      DB.update('products','product_id',prod,{qty:p.qty+qty});
    }
    Modal.close(); render(); renderDashboard();
    Toast.show('PO '+id+' created'+(status==='Completed'?' — Stock updated +'+qty:'')+'!');
  }

  function edit(id){
    var o=DB.byId('purchase_orders','po_id',id); if(!o) return;
    var stOpts=STATUSES.map(function(s){ return '<option'+(s===o.status?' selected':'')+'>'+s+'</option>'; }).join('');
    var p=DB.byId('products','product_id',o.product_id);
    Modal.open({
      title:'✏️ Edit PO — '+esc(id),
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Product ID (read-only)</label><input class="finp" value="'+esc(o.product_id)+'" readonly style="background:var(--bg2)"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Supplier ID</label><input id="e-sup" class="finp" value="'+esc(o.supplier_id)+'"></div>'+
        '<div class="fgrp"><label class="flbl">Quantity</label><input id="e-qty" class="finp" type="number" value="'+o.qty+'" oninput="PurchaseOrders._calcEditTotal(\''+esc(id)+'\')"></div>'+
        '<div class="fgrp"><label class="flbl">Unit Price (₹) — Locked</label><input class="finp" value="₹'+(p?p.price.toFixed(2):'N/A')+'" readonly style="background:var(--bg2)"></div>'+
        '<div class="fgrp fspan"><label class="flbl" style="color:var(--primary)">Total Price (₹) — Auto</label><input id="e-price" class="finp" value="'+o.price+'" readonly style="background:var(--bg2);font-weight:700"></div>'+
        '<div class="fgrp"><label class="flbl">Status</label><select id="e-status" class="finp">'+stOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Order Date</label><input id="e-odate" class="finp" type="date" value="'+esc(o.order_date||'')+'"></div>'+
        '<div class="fgrp"><label class="flbl">Delivery Date</label><input id="e-ddate" class="finp" type="date" value="'+esc(o.delivery_date||'')+'"></div>'+
        '<div class="fgrp fspan"><div class="info-box">⚠️ Changing status to <strong>Completed</strong> will increase product stock by the order quantity. This action is tracked.</div></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="PurchaseOrders.update(\''+esc(id)+'\')">💾 Update</button>'
    });
  }

  function _calcEditTotal(id){
    var o=DB.byId('purchase_orders','po_id',id);
    if(!o) return;
    var p=DB.byId('products','product_id',o.product_id);
    if(!p) return;
    var qty=intVal('e-qty');
    var el=document.getElementById('e-price');
    if(el) el.value=(p.price*qty).toFixed(2);
  }

  function update(id){
    var o=DB.byId('purchase_orders','po_id',id); if(!o) return;
    var oldStatus=o.status;
    var newStatus=val('e-status');
    var newQty=intVal('e-qty');
    var p=DB.byId('products','product_id',o.product_id);
    var totalPrice=p ? Math.round(p.price*newQty*100)/100 : o.price;

    DB.update('purchase_orders','po_id',id,{
      supplier_id:val('e-sup'), qty:newQty, price:totalPrice,
      status:newStatus, order_date:val('e-odate'), delivery_date:val('e-ddate')
    });

    /* If status changed TO Completed, add stock. If changed FROM Completed, reverse. */
    if(p){
      if(oldStatus!=='Completed' && newStatus==='Completed'){
        DB.update('products','product_id',o.product_id,{qty:p.qty+newQty});
        Toast.show('PO updated — Stock increased by '+newQty+' units!');
      } else if(oldStatus==='Completed' && newStatus!=='Completed'){
        var newQ=Math.max(0, p.qty-o.qty);
        DB.update('products','product_id',o.product_id,{qty:newQ});
        Toast.show('PO updated — Stock reversed by '+o.qty+' units!','warning');
      } else {
        Toast.show('Purchase Order updated!');
      }
    } else {
      Toast.show('Purchase Order updated!');
    }
    Modal.close(); render(); renderDashboard();
  }

  function del(id){
    _confirm('Purchase Order', id, function(){ DB.remove('purchase_orders','po_id',id); render(); renderDashboard(); Toast.show('PO '+id+' deleted','warning'); });
  }

  function setFilter(s){ _filter=s; _renderTable(DB.all('purchase_orders')); }
  return { render:render, openAdd:openAdd, save:save, edit:edit, update:update, del:del, setFilter:setFilter, _onProductChange:_onProductChange, _calcTotal:_calcTotal, _calcEditTotal:_calcEditTotal };
}());

/* ── SALES ORDERS ────────────────────────────────────────── */
var SalesOrders = (function(){
  var _filter='';
  var STATUSES=['Processing','Dispatched','Completed','Cancelled'];

  function render(){ _renderTable(DB.all('sales_orders')); }

  function _renderTable(rows){
    var f=filter(rows,_filter,['so_id','product_id','customer','status']);
    var html;
    if(!f.length){
      html='<tr><td colspan="9" class="empty-row"><span class="ei">📤</span>No sales orders found</td></tr>';
    } else {
      var prods=DB.all('products');
      html=f.map(function(o){
        var prod=prods.find(function(p){return p.product_id===o.product_id;});
        var pname=prod?prod.name:'Unknown';
        return '<tr>'+
          '<td class="td-id">'+esc(o.so_id)+'</td>'+
          '<td><span class="td-id">'+esc(o.product_id)+'</span><br><span style="font-size:.75rem;color:var(--t2)">'+esc(pname)+'</span></td>'+
          '<td><strong>'+esc(o.customer||'—')+'</strong></td>'+
          '<td style="font-family:var(--ff-mono);font-weight:600">'+o.qty.toLocaleString()+'</td>'+
          '<td class="price-cell">'+currency(o.price)+'</td>'+
          '<td style="font-size:.8rem;color:var(--t2)">'+currency(o.price/o.qty)+' / unit</td>'+
          '<td>'+fdate(o.sale_date)+'</td>'+
          '<td>'+statusBadge(o.status)+'</td>'+
          '<td><div class="td-act">'+
            '<button class="btn btn-warning btn-sm btn-ico" onclick="SalesOrders.edit(\''+esc(o.so_id)+'\')">✏️</button>'+
            '<button class="btn btn-danger btn-sm btn-ico" onclick="SalesOrders.del(\''+esc(o.so_id)+'\')">🗑️</button>'+
          '</div></td></tr>';
      }).join('');
    }
    q('#so-tbody').innerHTML=html;
    q('#so-count').textContent=f.length+' orders';
  }

  function openAdd(){
    var pOpts=DB.all('products').map(function(p){
      var salePrice=Math.round(p.price*1.10*100)/100;
      return '<option value="'+esc(p.product_id)+'">'+esc(p.product_id)+' — '+esc(p.name)+' (Stock: '+p.qty+', Sale: ₹'+salePrice+')</option>';
    }).join('');
    var stOpts=STATUSES.map(function(s){ return '<option>'+s+'</option>'; }).join('');
    Modal.open({
      title:'📤 Create Sales Order',
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Product *</label>'+
          '<select id="m-prod" class="finp" onchange="SalesOrders._onProductChange()"><option value="">— Select Product —</option>'+pOpts+'</select></div>'+
        '<div class="fgrp fspan"><label class="flbl">Customer Name *</label><input id="m-cust" class="finp" placeholder="Customer or company name"></div>'+
        '<div class="fgrp"><label class="flbl">Quantity *</label><input id="m-qty" class="finp" type="number" min="1" placeholder="0" oninput="SalesOrders._calcTotal()"></div>'+
        '<div class="fgrp"><label class="flbl">Unit Price (₹) — Cost+10% Profit</label><input id="m-unitprice" class="finp" type="text" readonly style="background:var(--bg2);cursor:not-allowed" placeholder="Select product first"></div>'+
        '<div class="fgrp fspan"><label class="flbl" style="color:var(--green);font-weight:700">Total Sale Price (₹) — Auto Calculated</label>'+
          '<input id="m-price" class="finp" type="text" readonly style="background:var(--bg2);cursor:not-allowed;font-weight:700;font-size:1rem;color:var(--green)" placeholder="0.00"></div>'+
        '<div class="fgrp"><label class="flbl">Status</label><select id="m-status" class="finp">'+stOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Sale Date</label><input id="m-sdate" class="finp" type="date" value="'+todayStr()+'"></div>'+
        '<div class="fgrp fspan"><div class="info-box">💡 Sale price = Product cost price <strong>+ 10% profit margin</strong>. Stock will decrease <strong>only when status = Completed</strong>.</div></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="SalesOrders.save()">💾 Create SO</button>'
    });
  }

  function _onProductChange(){
    var pid=val('m-prod');
    var upEl=document.getElementById('m-unitprice');
    var tpEl=document.getElementById('m-price');
    if(!pid){ if(upEl) upEl.value=''; if(tpEl) tpEl.value=''; return; }
    var p=DB.byId('products','product_id',pid);
    if(p){
      var salePrice=Math.round(p.price*1.10*100)/100;
      if(upEl) upEl.value='₹'+salePrice.toFixed(2)+' (cost ₹'+p.price.toFixed(2)+' +10%)';
      _calcTotal();
    }
  }

  function _calcTotal(){
    var pid=val('m-prod');
    var qty=intVal('m-qty');
    var tpEl=document.getElementById('m-price');
    if(!pid||!qty){ if(tpEl) tpEl.value=''; return; }
    var p=DB.byId('products','product_id',pid);
    if(p && tpEl){
      var total=Math.round(p.price*1.10*qty*100)/100;
      tpEl.value='₹'+total.toFixed(2);
    }
  }

  function save(){
    var prod=val('m-prod'), cust=val('m-cust');
    var qty=intVal('m-qty');
    var status=val('m-status');
    if(!prod||!cust||!qty){ Toast.show('Product, Customer & Quantity are required','error'); return; }
    var p=DB.byId('products','product_id',prod);
    if(!p){ Toast.show('Product not found!','error'); return; }
    /* Stock check ONLY for Completed (immediate deduction) */
    if(status==='Completed' && qty>p.qty){ Toast.show('Insufficient stock! Only '+p.qty+' units available.','error'); return; }
    var totalPrice=Math.round(p.price*1.10*qty*100)/100;
    var id=uid('SO');
    DB.add('sales_orders',{ so_id:id, product_id:prod, customer:cust, qty:qty, price:totalPrice, status:status, sale_date:val('m-sdate') });
    /* Stock decreases ONLY when status = Completed */
    if(status==='Completed'){
      DB.update('products','product_id',prod,{qty:p.qty-qty});
    }
    Modal.close(); render(); renderDashboard();
    Toast.show('SO '+id+' created'+(status==='Completed'?' — Stock reduced by '+qty:'')+'!');
  }

  function edit(id){
    var o=DB.byId('sales_orders','so_id',id); if(!o) return;
    var stOpts=STATUSES.map(function(s){ return '<option'+(s===o.status?' selected':'')+'>'+s+'</option>'; }).join('');
    var p=DB.byId('products','product_id',o.product_id);
    var saleUnitPrice=p ? Math.round(p.price*1.10*100)/100 : 0;
    Modal.open({
      title:'✏️ Edit SO — '+esc(id),
      body:'<div class="fgrid">'+
        '<div class="fgrp fspan"><label class="flbl">Product ID (read-only)</label><input class="finp" value="'+esc(o.product_id)+'" readonly style="background:var(--bg2)"></div>'+
        '<div class="fgrp fspan"><label class="flbl">Customer</label><input id="e-cust" class="finp" value="'+esc(o.customer||'')+'"></div>'+
        '<div class="fgrp"><label class="flbl">Quantity</label><input id="e-qty" class="finp" type="number" value="'+o.qty+'" oninput="SalesOrders._calcEditTotal(\''+esc(id)+'\')"></div>'+
        '<div class="fgrp"><label class="flbl">Sale Unit Price (₹) — Cost+10%</label><input class="finp" value="₹'+saleUnitPrice.toFixed(2)+'" readonly style="background:var(--bg2)"></div>'+
        '<div class="fgrp fspan"><label class="flbl" style="color:var(--green)">Total Sale Price (₹) — Auto</label><input id="e-price" class="finp" value="'+o.price+'" readonly style="background:var(--bg2);font-weight:700;color:var(--green)"></div>'+
        '<div class="fgrp"><label class="flbl">Status</label><select id="e-status" class="finp">'+stOpts+'</select></div>'+
        '<div class="fgrp"><label class="flbl">Sale Date</label><input id="e-sdate" class="finp" type="date" value="'+esc(o.sale_date||'')+'"></div>'+
        '<div class="fgrp fspan"><div class="info-box">⚠️ Changing status to <strong>Completed</strong> will deduct product stock. Changing away from Completed will restore it.</div></div>'+
      '</div>',
      footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
             '<button class="btn btn-primary" onclick="SalesOrders.update(\''+esc(id)+'\')">💾 Update</button>'
    });
  }

  function _calcEditTotal(id){
    var o=DB.byId('sales_orders','so_id',id);
    if(!o) return;
    var p=DB.byId('products','product_id',o.product_id);
    if(!p) return;
    var qty=intVal('e-qty');
    var el=document.getElementById('e-price');
    if(el) el.value=(Math.round(p.price*1.10*qty*100)/100).toFixed(2);
  }

  function update(id){
    var o=DB.byId('sales_orders','so_id',id); if(!o) return;
    var oldStatus=o.status;
    var newStatus=val('e-status');
    var newQty=intVal('e-qty');
    var cust=val('e-cust');
    var p=DB.byId('products','product_id',o.product_id);
    var totalPrice=p ? Math.round(p.price*1.10*newQty*100)/100 : o.price;

    /* Stock check if moving to Completed */
    if(p && oldStatus!=='Completed' && newStatus==='Completed'){
      if(newQty>p.qty){ Toast.show('Insufficient stock! Only '+p.qty+' units available.','error'); return; }
    }

    DB.update('sales_orders','so_id',id,{ customer:cust, qty:newQty, price:totalPrice, status:newStatus, sale_date:val('e-sdate') });

    if(p){
      if(oldStatus!=='Completed' && newStatus==='Completed'){
        DB.update('products','product_id',o.product_id,{qty:p.qty-newQty});
        Toast.show('SO updated — Stock reduced by '+newQty+' units!');
      } else if(oldStatus==='Completed' && newStatus!=='Completed'){
        DB.update('products','product_id',o.product_id,{qty:p.qty+o.qty});
        Toast.show('SO updated — Stock restored by '+o.qty+' units!','warning');
      } else {
        Toast.show('Sales Order updated!');
      }
    } else {
      Toast.show('Sales Order updated!');
    }
    Modal.close(); render(); renderDashboard();
  }

  function del(id){
    _confirm('Sales Order', id, function(){ DB.remove('sales_orders','so_id',id); render(); renderDashboard(); Toast.show('SO '+id+' deleted','warning'); });
  }

  function setFilter(s){ _filter=s; _renderTable(DB.all('sales_orders')); }
  return { render:render, openAdd:openAdd, save:save, edit:edit, update:update, del:del, setFilter:setFilter, _onProductChange:_onProductChange, _calcTotal:_calcTotal, _calcEditTotal:_calcEditTotal };
}());

/* ── CONFIRM HELPER ──────────────────────────────────────── */
function _confirm(type, id, onOk){
  Modal.open({
    title:'⚠️ Delete '+type,
    body:'<div class="confirm-box">'+
      '<div class="confirm-icon">🗑️</div>'+
      '<div>You are about to permanently delete <strong>'+esc(id)+'</strong>.<br>This action <strong>cannot be undone</strong>.</div>'+
    '</div>',
    footer:'<button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>'+
           '<button class="btn btn-danger" id="cfm-btn">🗑️ Yes, Delete</button>'
  });
  setTimeout(function(){
    var btn=document.getElementById('cfm-btn');
    if(btn) btn.addEventListener('click', function(){ onOk(); Modal.close(); });
  }, 30);
}

/* ── GLOBAL SEARCH ───────────────────────────────────────── */
function handleGlobalSearch(q_val){
  var cur=Nav.getCurrent();
  if(cur==='products')             Products.setFilter(q_val);
  else if(cur==='suppliers')       Suppliers.setFilter(q_val);
  else if(cur==='warehouses')      Warehouses.setFilter(q_val);
  else if(cur==='purchase_orders') PurchaseOrders.setFilter(q_val);
  else if(cur==='sales_orders')    SalesOrders.setFilter(q_val);
}

/* ── BOOT ────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function(){
  DB.init();
  Modal.init();

  Nav.register('dashboard',       renderDashboard);
  Nav.register('products',        function(){ Products.render(); });
  Nav.register('suppliers',       function(){ Suppliers.render(); });
  Nav.register('warehouses',      function(){ Warehouses.render(); });
  Nav.register('purchase_orders', function(){ PurchaseOrders.render(); });
  Nav.register('sales_orders',    function(){ SalesOrders.render(); });

  qa('.nav-item[data-page]').forEach(function(el){
    el.addEventListener('click', function(){ Nav.go(el.getAttribute('data-page')); });
  });

  document.getElementById('g-search').addEventListener('input', function(){ handleGlobalSearch(this.value.trim()); });

  document.getElementById('btn-reset').addEventListener('click', function(){
    if(confirm('Reset all data to defaults? This will clear all your changes.')){
      DB.reset(); Nav.go('dashboard'); Toast.show('Database reset to defaults','info');
    }
  });

  document.getElementById('btn-export').addEventListener('click', function(){
    try {
      var data=JSON.stringify({ products:DB.all('products'), suppliers:DB.all('suppliers'), warehouses:DB.all('warehouses'), purchase_orders:DB.all('purchase_orders'), sales_orders:DB.all('sales_orders') },null,2);
      var a=document.createElement('a');
      a.href='data:application/json,'+encodeURIComponent(data);
      a.download='invenpro_export_'+todayStr()+'.json'; a.click();
      Toast.show('Data exported as JSON!');
    } catch(e){ Toast.show('Export failed','error'); }
  });

  Nav.go('dashboard');
});
