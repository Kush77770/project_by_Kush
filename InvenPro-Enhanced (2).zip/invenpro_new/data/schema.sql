-- ============================================================
-- InvenPro IMS — MySQL Database Schema
-- Run this in MySQL Workbench or CLI: mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS invenpro_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE invenpro_db;

-- ── WAREHOUSES ──────────────────────────────────────────────
DROP TABLE IF EXISTS sales_orders;
DROP TABLE IF EXISTS purchase_orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS warehouses;

CREATE TABLE warehouses (
  warehouse_id  VARCHAR(20)  PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  location      VARCHAR(255) NOT NULL,
  manager       VARCHAR(100),
  capacity      INT UNSIGNED DEFAULT 5000,
  used          INT UNSIGNED DEFAULT 0,
  phone         VARCHAR(30),
  created       DATE DEFAULT (CURRENT_DATE)
);

-- ── SUPPLIERS ───────────────────────────────────────────────
CREATE TABLE suppliers (
  supplier_id VARCHAR(20)  PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  contact     VARCHAR(100),
  phone       VARCHAR(30)  NOT NULL,
  email       VARCHAR(120),
  address     VARCHAR(255),
  rating      DECIMAL(3,1) DEFAULT 4.0 CHECK (rating BETWEEN 1.0 AND 5.0),
  created     DATE DEFAULT (CURRENT_DATE)
);

-- ── PRODUCTS ────────────────────────────────────────────────
CREATE TABLE products (
  product_id   VARCHAR(20)  PRIMARY KEY,
  name         VARCHAR(150) NOT NULL,
  sku          VARCHAR(50)  UNIQUE NOT NULL,
  category     ENUM('Mechanical','Electronics','Fluids','Safety','Tools','Other') DEFAULT 'Other',
  qty          INT UNSIGNED NOT NULL DEFAULT 0,
  price        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reorder      INT UNSIGNED DEFAULT 50,
  warehouse_id VARCHAR(20),
  supplier_id  VARCHAR(20),
  created      DATE DEFAULT (CURRENT_DATE),
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id) ON DELETE SET NULL,
  FOREIGN KEY (supplier_id)  REFERENCES suppliers(supplier_id)   ON DELETE SET NULL
);

-- ── PURCHASE ORDERS ─────────────────────────────────────────
CREATE TABLE purchase_orders (
  po_id         VARCHAR(30) PRIMARY KEY,
  product_id    VARCHAR(20) NOT NULL,
  supplier_id   VARCHAR(20) NOT NULL,
  qty           INT UNSIGNED NOT NULL,
  price         DECIMAL(14,2) NOT NULL,
  status        ENUM('Pending','In Transit','Delivered','Cancelled') DEFAULT 'Pending',
  order_date    DATE DEFAULT (CURRENT_DATE),
  delivery_date DATE,
  FOREIGN KEY (product_id)  REFERENCES products(product_id)  ON DELETE RESTRICT,
  FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE RESTRICT
);

-- ── SALES ORDERS ────────────────────────────────────────────
CREATE TABLE sales_orders (
  so_id      VARCHAR(30) PRIMARY KEY,
  product_id VARCHAR(20) NOT NULL,
  customer   VARCHAR(150),
  qty        INT UNSIGNED NOT NULL,
  price      DECIMAL(14,2) NOT NULL,
  status     ENUM('Processing','Dispatched','Completed','Cancelled') DEFAULT 'Processing',
  sale_date  DATE DEFAULT (CURRENT_DATE),
  FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
);

-- ── SEED DATA ────────────────────────────────────────────────
INSERT INTO warehouses VALUES
('WH-001','Alpha Hub - Pune',    'Plot 21, Bhosari MIDC, Pune',       'Deepak Joshi',  5000,3200,'020-27120001','2023-01-10'),
('WH-002','Beta Store - Chennai','Manali Industrial Estate, Chennai',  'Kavitha Rajan', 3000,1750,'044-25941234','2023-03-05'),
('WH-003','Gamma Depot - Surat', 'Sachin GIDC, Surat',                'Himesh Trivedi',4000,2890,'0261-2397001','2023-04-20');

INSERT INTO suppliers VALUES
('SUP-001','MechPro Industries', 'Rajesh Sharma','+91-9876543210','rajesh@mechpro.in', 'Plot 14, MIDC, Pune',              4.8,'2023-06-01'),
('SUP-002','FluidTech Solutions','Priya Menon',  '+91-9123456789','priya@fluidtech.in','52 Industrial Area, Chennai',       4.2,'2023-07-15'),
('SUP-003','AutoElec Systems',   'Vikram Nair',  '+91-9988776655','vikram@autoelec.in','Electronics City, Bangalore',       4.9,'2023-05-20'),
('SUP-004','SafeGuard Supplies', 'Anita Patel',  '+91-9345678901','anita@safeguard.in','Ring Road, Surat',                  4.5,'2023-08-10'),
('SUP-005','PrecisionTools Co.', 'Suresh Kumar', '+91-9654321098','suresh@prectools.in','Sector 44, Faridabad',             4.6,'2023-09-01');

INSERT INTO products VALUES
('PRD-001','Industrial Steel Bearings','ISB-6205',  'Mechanical', 1240, 45.99, 200,'WH-001','SUP-001','2024-01-15'),
('PRD-002','Hydraulic Fluid 46',       'HF-46L',    'Fluids',       85,129.50, 100,'WH-002','SUP-002','2024-02-10'),
('PRD-003','PLC Control Module',       'PLC-S7-300','Electronics',  34, 879.00,  20,'WH-001','SUP-003','2024-01-20'),
('PRD-004','Safety Helmets (Class E)', 'SH-CE-WHT', 'Safety',      620,  24.99, 150,'WH-003','SUP-004','2024-03-05'),
('PRD-005','Conveyor Belt 3M',         'CB-3M-B2',  'Mechanical',   18,1250.00,  10,'WH-002','SUP-001','2024-02-28'),
('PRD-006','Digital Torque Wrench',    'DTW-50NM',  'Tools',        72, 340.00,  30,'WH-003','SUP-005','2024-03-12'),
('PRD-007','Nitrile Gloves (100pk)',   'NG-100-M',  'Safety',     2100,  18.75, 500,'WH-003','SUP-004','2024-01-08'),
('PRD-008','Servo Motor 750W',         'SM-750W-AC','Electronics',   9,1450.00,  10,'WH-001','SUP-003','2024-04-01');

INSERT INTO purchase_orders VALUES
('PO-2024-001','PRD-002','SUP-002', 200,25900,'Delivered', '2024-03-10','2024-03-18'),
('PO-2024-002','PRD-008','SUP-003',  15,21750,'In Transit','2024-03-28','2024-04-05'),
('PO-2024-003','PRD-001','SUP-001', 500,22995,'Pending',   '2024-04-02','2024-04-15'),
('PO-2024-004','PRD-007','SUP-004',1000,18750,'Delivered', '2024-02-20','2024-02-27');

INSERT INTO sales_orders VALUES
('SO-2024-001','PRD-001','TechBuild Corp',  300,13797,'Completed', '2024-03-15'),
('SO-2024-002','PRD-004','SafeWork Ltd',    150, 3748,'Dispatched','2024-03-30'),
('SO-2024-003','PRD-006','AutoFab India',    20, 6800,'Processing','2024-04-03'),
('SO-2024-004','PRD-003','Robolink Systems',  8, 7032,'Completed', '2024-02-25');

-- ── VIEWS ────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_stock_status AS
SELECT p.product_id, p.name, p.sku, p.category, p.qty, p.reorder,
       p.price, ROUND(p.qty*p.price,2) AS total_value,
       w.name AS warehouse,
       CASE WHEN p.qty=0 THEN 'Out of Stock' WHEN p.qty<=p.reorder THEN 'Low Stock' ELSE 'In Stock' END AS status
FROM products p LEFT JOIN warehouses w ON p.warehouse_id=w.warehouse_id;
